/*  
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
package com.i2i.employeemanagement.utility; 
 
/**
 *  This helper class helps to mask the confidential fields. 
 */  
public class ProjectUtility {

    public static int projectId = 1111;
    
    /**
     *  This method is used to generate projectID
     *
     *  @return auto-generatedprojectId 
     */
    public static int projectId() {
        return projectId++;
    }
    
}

/**  
 *  Copyright (c) All rights reserved.
 */

package com.i2i.employeemanagement.dto;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.lang.StringBuilder;

import com.i2i.employeemanagement.dto.ProjectDTO;
import com.i2i.employeemanagement.model.PhoneNumber;
import com.i2i.employeemanagement.model.SeatAllotment;
import com.i2i.employeemanagement.model.Address;
import com.i2i.employeemanagement.utility.EmployeeUtility;
/**
 *  This class has Attributes of Employee
 *
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
public class EmployeeDTO {

    public static String companyName = "Ideas2IT";
    private String employeeName;
    private int id; 
    private String emailId;	
    private Set<PhoneNumber> phoneNumber; 
    private String designation; 
    private String qualification;
    private double salary;        
    private String accountNumber; 
    private String ifscCode;
    private SeatAllotment seat;	
    private List<Address> addresses;
    private Set<ProjectDTO> projects;
    
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    
    public String getCompanyName() {
        return companyName;
    }
    
    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeName() {
        return employeeName;
    }
    
    public void setEmployeeId(int generateEmployeeId) {
        this.id = generateEmployeeId;
    }

    public int getEmployeeId() {
        return id;
    }
 
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getEmailId() {
        return emailId;
    }
    
    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDesignation() {
        return designation;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getQualification() {
        return qualification;
    }  

    public void setSalary(double salary) {
        this.salary =  salary * 12;
    }
    
    public double getSalary() {
        return salary;
    }
   
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

    public String getIfscCode() {
        return ifscCode;
    }    

    public void setSeat(SeatAllotment seat) {
    	this.seat = seat;
	}
	
	public SeatAllotment getSeat() {
        return seat;
	}

    public void setPhoneNumber(Set<PhoneNumber> phoneNumber) {
    	this.phoneNumber = phoneNumber;
    }

    public Set<PhoneNumber> getPhoneNumber() {
        return phoneNumber;
    }
    
    public void setAddress(List<Address> addresses) {
        this.addresses = addresses;
    }

    public List<Address> getAddress() {
        return addresses;
    }

    public void setProject(Set<ProjectDTO> projects) {
        this.projects = projects;
    } 
 
    public Set<ProjectDTO> getProject() {
        return projects;
    }   
    
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        return stringBuilder.append("\n CompanyName:").append(getCompanyName())
        .append("\n Name: ").append(getEmployeeName()).append("\n EmployeeID: ")
        .append(getEmployeeId()).append("\n EmailId: ").append(getEmailId())
        .append("\n Qualification:").append(getQualification())
        .append("\n Designation:").append(getDesignation()).append("\n Account Number:")
        .append(EmployeeUtility.maskAccountNumber(getAccountNumber()))
        .append("\n IFSC Code: ").append(getIfscCode()).append("\n Seat").append(getSeat())
        .append("\n Address:").append(getAddress()).append("\n PhoneNumber:")
        .append(getPhoneNumber()).append("s\n Salary:").append(getSalary()).toString();
    }	                   
}


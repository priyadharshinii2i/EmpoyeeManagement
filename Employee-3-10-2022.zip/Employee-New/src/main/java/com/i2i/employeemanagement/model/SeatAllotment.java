/**  
 *  Copyright (c) All rights reserved.
 */
package com.i2i.employeemanagement.model;

import com.i2i.employeemanagement.dto.EmployeeDTO;
import java.lang.StringBuilder;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/*  
 *  This class has Attributes of SeatAllotment
 *
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */

public class SeatAllotment{

	@Id
	@Column(name="Id")
	@GeneratedValue(strategy=GenerationType.AUTO)
    private int id;
	
	@Column(name="first_floor_number")
    private String firstFloorSeatNumber;
	
	@Column(name="second_floor_number")
    private String secondFloorSeatNumber;
	
	@Column(name="floor_number")
    private int floorNumber;
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getId() {
        return id;
    }
    
    public void setFirstFloorSeatNumber(String firstFloorSeatNumber) {
        this.firstFloorSeatNumber = firstFloorSeatNumber;
    }
    
    public String getFirstFloorSeatNumber() {
        return firstFloorSeatNumber;
    }

    public void setSecondFloorSeatNumber(String secondFloorSeatNumber) {
        this.secondFloorSeatNumber = secondFloorSeatNumber;
    }
    
    public String getSecondFloorSeatNumber() {
        return secondFloorSeatNumber;
    }
    
    public void setFloorNumber(int floorNumber) {
        this.floorNumber = floorNumber;
    }

    public int getFloorNumber() {
        return floorNumber;
    }
    
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        return stringBuilder.append("\n FirstFloorSeatNumber:").append(getFirstFloorSeatNumber())
               .append("\n SecondFloorSeatNumber:").append(getSecondFloorSeatNumber())
               .append("\n 1" +
                       "floorNumber:").append(getFloorNumber()).toString();
    }
}


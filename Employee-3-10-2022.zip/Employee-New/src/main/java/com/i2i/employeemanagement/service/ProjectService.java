/*  
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
package com.i2i.employeemanagement.service;

import java.util.Map;

import com.i2i.employeemanagement.dto.ProjectDTO;
import com.i2i.employeemanagement.model.Project;

/**
 *  This class used to create, search, update, display, delete
 *  project
 *
 */
public interface ProjectService {

    /** 
     *  Used to add project  
     *
     *  @param project to be added 
     *
     *  @param id to be added
     *
     *  @return created id
     */ 
    public int addProject(int id, ProjectDTO projectDTO);
    
    /**
     *  Used to search ProjectProject
     * 
     *  @param employeeId used to find project
     *  
     *  @return project 
     *  
     */
    public ProjectDTO searchProjectDetailById(int id);

    /** 
     *  Used to update project 
     *
     *  @param emlopyeeId is to find project
     *
     *  @return updated employeeId 
     */
    public int updateProjectDetailById(int id, ProjectDTO projectDTO);

    /** 
     *  Used to display project 
     *
     *  @return project detail
     */
    public Map<Integer,ProjectDTO> showProjectDetail();

    /** 
     *  Remove project 
     *
     *  @param employeeId is to find project
     *
     *  @return deleted employeeId        
     */
    public int deleteProjectDetailById(int id);
    
    /** 
     *  assign employee to project 
     *
     *  @param employeeId is to find employee
     *
     *  @param projectId is to find project        
     */
    public void assignEmployeeToProject(int employeeId, int projectId); 
}



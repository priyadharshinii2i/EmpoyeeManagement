/**  
 *  
 *  Copyright (c) All rights reserved.
 *  
 */
package com.i2i.employeemanagement.singleton;

import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;

public class Singleton {
   
    private static SessionFactory sessionFactory = null;
    private static Singleton singleton = null;
    
    private Singleton() {
        sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    }
    
    public static Singleton getInstance() {
        if (sessionFactory == null) {
            singleton = new Singleton();
        }
        return singleton;
    }
    
    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}

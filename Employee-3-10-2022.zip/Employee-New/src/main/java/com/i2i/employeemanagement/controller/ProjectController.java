/*  
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
package com.i2i.employeemanagement.controller;

//import java.util.InputMismatchException;
import java.util.HashSet;
import org.apache.log4j.Logger;
import java.util.Map;
import java.io.IOException;
import java.io.PrintWriter;
//import java.lang.NumberFormatException;
import java.util.Scanner;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.i2i.employeemanagement.dto.EmployeeDTO;
import com.i2i.employeemanagement.dto.ProjectDTO;
//import com.i2i.employeemanagement.MainApplication;
import com.i2i.employeemanagement.service.EmployeeService;
import com.i2i.employeemanagement.service.impl.EmployeeServiceImpl;
import com.i2i.employeemanagement.service.ProjectService;
import com.i2i.employeemanagement.service.impl.ProjectServiceImpl;
//import com.i2i.employeemanagement.utility.ProjectValidation;
//import com.i2i.employeemanagement.utility.ProjectUtility;


/**
 *  This class used to create, search, update, display, delete Project
 */
public class ProjectController extends HttpServlet {

    //Scanner scanner = new Scanner(System.in);
    EmployeeService employeeService = new EmployeeServiceImpl();
    ProjectService projectService = new ProjectServiceImpl();
    private static Logger logger = Logger.getLogger(ProjectController.class);
    
    /**
     *  Direct the user to Insert, search, Update
     *  Display and Delete trainer detail
     */
   /* public void getProjectPortal() {
        int choice = 0;        
        do {
            System.out.println(" Press- 1. To Insert detail of Project");
            System.out.println(" Press- 2. To Search detail of Project");
            System.out.println(" Press- 3. To update detail of Project");
            System.out.println(" Press- 4. To Display detail of Project"); 
            System.out.println(" Press- 5. To delete detail of Project"); 
            System.out.println(" Press- 6. To Assign Employee to Project");
            System.out.println(" Press- 7. To Exit");
            try {
                choice = Integer.parseInt(scanner.nextLine());
            
                switch (choice) {
                    case 1:
                        getProject();
                        break;
	 
                    case 2:
                        searchProjectDetail();
                        break;
                
                    case 3:

                        updateProjectDetail();
                        break;

                    case 4:
                        System.out.println("DISPLAY DETAILS OF PROJECT");
                        System.out.println(projectService.showProjectDetail());        
                        break; 
            
                    case 5:
                        int id;
                        System.out.println("DELETE  PROJECT");
                        System.out.println("Enter ProjectID:");
                        id = scanner.nextInt();
                        int deleteProject = projectService.
                                            deleteProjectDetailById(id);
                        logger.info("Project "+ deleteProject
                                           + " record deleted");
                        break;
                        
                    case 6:
                        assignEmployeeToProject();
                        break;
                                           
                    case 7:
                        System.out.println("BACK TO MAIN MENU");
                        MainApplication.menu();
                        break;

                    default:
                        logger.warn("INVALID");
                }
            } catch (NumberFormatException numberFormatException) {
                logger.info("ENTER NUMERICAL OPTION [1-6]");
            }   
        } while (choice != 7); 
    }*/

    /**
     *  create new Project
     */
    /*public void getProject() {
        
        String name;
		String softwareRequirement;
        String description;
        String noOfMembers;
               
        ProjectDTO projectDTO = new ProjectDTO();
        System.out.println("\nEnter Name of the Project");
        
        do {
            name = scanner.nextLine();
            if (ProjectValidation.isValidProjectName(name)) {
                projectDTO.setName(name);
            } else {
                System.out.println("Enter valid name");
            }
        } while (!ProjectValidation.isValidProjectName(name)); 
        		
        projectDTO.setId(ProjectUtility.projectId());

        System.out.println("\nEnter SoftwareRequirement of the Project");
        do {
            softwareRequirement = scanner.nextLine();
            if (ProjectValidation.isValidSoftwareRequirement(softwareRequirement)) {
                projectDTO.setSoftwareRequirement(softwareRequirement);
            } else {
                logger.warn("Enter valid SoftwareRequirement");
            }
        } while (!ProjectValidation.isValidSoftwareRequirement(softwareRequirement));   

        System.out.println("\nEnter Description of the Project");
        do {
            description = scanner.nextLine();
            if (ProjectValidation.isValidDescription(description)) {
                projectDTO.setDescription(description);
            } else {
                logger.warn("Enter Valid Description of Project");
            }
        } while (!ProjectValidation.isValidDescription(description));
  
        System.out.println("\nEnter noOfMember in project: ");
        do {
            noOfMembers = scanner.nextLine();
            if (ProjectValidation.isValidNoOfMember(noOfMembers)) {
                projectDTO.setNoOfMembers(Integer.parseInt(noOfMembers));
            } else {
                logger.warn("Enter Valid Input");
            }
        } while (!ProjectValidation.isValidNoOfMember(noOfMembers));
        int projectId = projectService.addProject(projectDTO.getId(),
                           projectDTO);
        logger.info("Project "+ projectId + " CREATED");         
    } */

    /**
     *  search detail from the Project
     */
   /* public void searchProjectDetail() {
        int choice = 0;

        System.out.println("SEARCH PARTICULAR DETAIL OF PROJECT");
        try {
           
            System.out.println("Enter projectID:");
        	int id = Integer.parseInt(scanner.nextLine());
            ProjectDTO projectDTO = projectService.searchProjectDetailById(id);
            if (projectDTO != null) {
                do {
                	System.out.println("\nPRESS BELOW GIVEN NUMBER");
                	System.out.println("1.PROJECT NAME");
                	System.out.println("2.SOFTWARE REQUIREMENT");
                	System.out.println("3.DESCRIPTION");
                    System.out.println("4.NO OF MEMBERS");
                	System.out.println("5.EXIT");
                	try {
                        choice = Integer.parseInt(scanner.nextLine());
                        switch (choice) {
                            case 1:
                 		    	System.out.println("\nProject Name:" 
                 		    	        + projectDTO.getName());
                   		    	break;

               			    case 2:
                   		    	System.out.println("\nSoftwareRequirement:"
                   		    	        + projectDTO.getSoftwareRequirement());
                   		    	break;

               			    case 3: 
                   		       	System.out.println("\nProject Description:"
                   		       	        + projectDTO.getDescription());
                   			    break;
                   			
                		    case 4:
                    	    	System.out.println("\nNo.Of.Members:"
                    	    	        + projectDTO.getNoOfMembers());
                   		    	break;
                   		    	
                   	        case 5:
                    	    	System.out.println("EXIT");
                   		    	break;
                    	    
                		    default:
                   		    	System.out.println("Enter Numeric Number [1-5]");
               		    }
               		} catch (NumberFormatException numberFormatException) {
               		    System.out.println("Enter Numeric Number [1-5]");
               		}
                } while (choice != 5); 
        	} else {
            	logger.info("Project Not Found");
        	}
		} catch(NumberFormatException numberFormatException) {
        	logger.warn("Enter valid project ID");
		}
    } */
    
    /** 
     *  Update project detail 
     */
   /* public void updateProjectDetail() {
        int choice = 0;
        int id;
        
        System.out.println("UPDATE PARTICULAR DETAIL OF PROJECT");
        try {
           
        	System.out.println("Enter project ID:");
            id = Integer.parseInt(scanner.nextLine());
            ProjectDTO projectDTO = projectService
            		.searchProjectDetailById(id);
            if (projectDTO != null) {
            	do {
            		System.out.println("\nPRESS BELOW GIVEN NUMBER");
            		System.out.println("1.PROJECT NAME");
            		System.out.println("2.PROJECT DESCRIPTION");
            		System.out.println("3.NO OF MEMBERS");
            		System.out.println("4.EXIT");
                    try {
                		choice = Integer.parseInt(scanner.nextLine());
            			switch (choice) {
            			
            			    case 1: 
           	 	        	    System.out.println(projectDTO.getName());
                			    break;
                			    
           	 	        	case 2:
           	 	        	    projectDescription(id,projectDTO);
                			    break;
 
            			    case 3:
            			        projectMembers(id, projectDTO);
                			    break;
                			    
            			    case 4:
                			    System.out.println("EXIT");
                			    break;

            			default:  
                			System.out.println("Enter Numeric value [1-3]");
            			} 
					} catch(NumberFormatException numberFormatException) {
						logger.warn("Enter Valid Numeric Number");
					}
        		} while (choice != 4);
    		} else {
				logger.info("Project ID not Found");
			} 
		} catch(InputMismatchException inputMismatchException) {
			logger.warn("Enter Valid project");
		}
    }*/
    
  /*  public void showProjectDetail() {
 
        Map<Integer, ProjectDTO> projectDTO = projectService
                .showProjectDetail();
        if(! projectDTO.isEmpty()) {
			for (ProjectDTO projectDto : projectDTO.values())
			    System.out.println(projectDto);
	    } else {
            logger.info("EMPLOYEE NOT FOUND");
        }
    }*/

    /**
     *  Delete employee
     */
  /*  public void deleteProject() {
        System.out.println("DELETE PARTICULAR DETAIL OF PROJECT");
		try {
		    System.out.println("Enter ProjectID:");
		    int id = Integer.parseInt(scanner.nextLine());
		    int deleteProject = projectService
	                .deleteProjectDetailById(id);
            if (deleteProject != 0) {
                logger.info("Project " + deleteProject 
		                    + " record deleted");
            } else {
                    logger.info("\nTHERE IS NO EMPLOYEE FOUND");
            }
		} catch (NumberFormatException numberFormatException) {
		    logger.warn("ENTER VALID EMPLOYEE-ID");
        }
    }*/

   //assign employee to project
  /* public void assignEmployeeToProject() {
        
        System.out.println("ENTER PROJECT ID");
        int id = Integer.parseInt(scanner.nextLine());
        ProjectDTO projectDTO = projectService.searchProjectDetailById(id);
        if (null != projectDTO) {
            
            System.out.println("ENTER EMPLOYEE ID");
            int employeeId = Integer.parseInt(scanner.nextLine());
        	EmployeeDTO employeeDTO = employeeService
                    .searchEmployeeDetailById(employeeId);
            if (null != employeeDTO) {
            	
            	Set<EmployeeDTO> employees = new HashSet<EmployeeDTO>();
                employees.add(employeeDTO);
                Set<ProjectDTO> projects = new HashSet<ProjectDTO>();
                projects.add(projectDTO);
                projectDTO.setEmployee(employees);
                employeeDTO.setProject(projects);
                int projectId = projectService
                		.updateProjectDetailById(id, projectDTO);		
                employeeId = employeeService.updateEmployeeDetailById
                        (employeeDTO);      
                logger.info("Project" + projectId + "Assigned to" 
                        + employeeId);
            } else {
            	logger.info("NO EMPLOYEE FOUND"); 
			}
         } else {
            logger.info("NO PROJECT FOUND"); 
         }
    }*/
    
    /*
     * This method used to validate projectDescription
     *
     * @param id used to find projectId
     *
     * @param projectDTO is used to find project
     *
     */
  /*  public void projectDescription(int id, ProjectDTO projectDTO) {
        
        String description;
     
        do {
            System.out.println("Enter project Description:");
            description = scanner.nextLine();              
           
            if (ProjectValidation.isValidDescription(description)) {
                projectDTO.setDescription(description);;
                int updateProject = projectService.
                        updateProjectDetailById(id,projectDTO); 
                logger.info("Updated Project "
                        + updateProject + " recorded " );
            } else {
                logger.warn("Enter valid input");
            }		
        } while (!ProjectValidation.isValidDescription(description));
    }*/
    
    /*
     * This method used to validate projectMembers
     *
     * @param id used to find projectId
     *
     * @param projectDTO is used to find project
     *
     */
  /*  public void projectMembers(int id, ProjectDTO projectDTO) {
    
        String noOfMembers;
        
        do {
            System.out.println("Enter No of members in project:");
            noOfMembers = scanner.nextLine(); 
            projectDTO.setId(id);             
            if (ProjectValidation.isValidNoOfMember(noOfMembers)) {
                projectDTO.setNoOfMembers(Integer.parseInt(noOfMembers));
                int updateProject = projectService.
                        updateProjectDetailById(id, projectDTO); 
                logger.info("Updated Project " 
                        + updateProject + " recorded " );
            } else {
                logger.warn("Enter valid input");
            }
        } while (!ProjectValidation.isValidNoOfMember(noOfMembers));	
    }*/
    
    /*
     * This method used to validate projectSoftwareRequirement
     *
     * @param id used to find projectId
     *
     * @param projectDTO is used to find project
     *
     */
  /*  public void projectSoftwareRequirement(int id, ProjectDTO projectDTO) {
    
        String noOfMembers; 
        do {
            System.out.println("Enter No of members in project:");
            noOfMembers = scanner.nextLine();              
            
            if (ProjectValidation.isValidNoOfMember(noOfMembers)) {
                projectDTO.setNoOfMembers(Integer.parseInt(noOfMembers));
                int updateProject = projectService.
                        updateProjectDetailById(id, projectDTO); 
                logger.info("Updated Project " 
                        + updateProject + " recorded " );
            } else {
                System.out.println("Enter valid input");
            }
        } while (!ProjectValidation.isValidNoOfMember(noOfMembers));	
    }*/
    
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	PrintWriter out = response.getWriter();
     	String value = request.getParameter("operation");
     	switch (value) {
     	case "InsertProject": 
     		add(request,response);
     		break;
     	
     	case "UpdateProject":
     		update(request,response);	 
     		break;
     	}
    }   
    public void add(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	response.setContentType("text/html");
        String projectName = request.getParameter("name");
        String softwareRequirement = request.getParameter("SoftwareRequirement");
        String description = request.getParameter("description");
        String noOfMembers = request.getParameter("no.of.members");
            
        ProjectDTO projectDTO = new ProjectDTO();
        projectDTO.setName(projectName);
        projectDTO.setSoftwareRequirement(softwareRequirement);
        String x= projectDTO.getSoftwareRequirement();
        System.out.println(x +"@@@@@");
        projectDTO.setDescription(description);
        projectDTO.setNoOfMembers(Integer.parseInt(noOfMembers));
        int projectId = projectService.addProject(projectDTO.getId(),
                 projectDTO);      
        logger.info("Project "+ projectId + " CREATED"); 
    	}
    
    public void update(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String projectId = request.getParameter("projectId");
        logger.info("Project "+ projectId + " CREATED"); 
        int id = Integer.parseInt(projectId);        
        ProjectDTO projectDTO = projectService.searchProjectDetailById(id);
        logger.info("Project "+ projectDTO + " CREATED"); 
         if (null != projectDTO) {
        	 String name = request.getParameter("name");
        	 String softwareRequirement = request.getParameter("SoftwareRequirement");
        	 String description = request.getParameter("description");
        	 String noOfMembers = request.getParameter("no.of.members");
        	 projectDTO.setName(name);
        	 projectDTO.setSoftwareRequirement(softwareRequirement);
        	 projectDTO.setNoOfMembers(Integer.parseInt(noOfMembers));
        	 projectDTO.setDescription(description);;
             int updateProject = projectService.
                     updateProjectDetailById(id,projectDTO); 
             logger.info("Updated Project " 
                     + updateProject + " recorded " );
         } else {
        	 out.println("No data found");
         }	 
    }
  
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
        
        PrintWriter out = response.getWriter();
    	String value = request.getParameter("operation");
        out.println(value);
    	switch (value) {
    	
    	case "Search": 
    		search(request,response);
    		break;
    	
    	case "Display":
    		display(request,response);	 
    		break;
    
    	case "Delete":
    		delete(request,response);	 
    		break;
    		
    	case "Assign":
    		assign(request,response);	 
    		break;
    	}
    }
    
    public void search(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
    	response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String projectId = request.getParameter("projectId");
        int id = Integer.parseInt(projectId);        
        ProjectDTO projectDTO = projectService.searchProjectDetailById(id);
         if (null != projectDTO) {
        	 out.println(projectDTO);
         } else {
        	 out.print("<h4> no data found </h4>");
         }
    }
    
    public void display(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
    	response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Map<Integer, ProjectDTO> projectDTO = projectService
                .showProjectDetail();
        if(! projectDTO.isEmpty()) {
			for (ProjectDTO projectDto : projectDTO.values())
			   out.println(projectDto);
	    } else {
            logger.info("EMPLOYEE NOT FOUND");
        }
    }
    
    public void delete(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
    	response.setContentType("text/html");
        String projectId = request.getParameter("projectId");
        int id = Integer.parseInt(projectId);        
        int deleteProject = projectService
                .deleteProjectDetailById(id);
        if (deleteProject != 0) {
            logger.info("Project " + deleteProject 
	                    + " record deleted");
        } else {
                logger.info("\nTHERE IS NO EMPLOYEE FOUND");
        }
    }
    
    public void assign(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
    	String projectId = request.getParameter("projectId");
        int id = Integer.parseInt(projectId);      
    	ProjectDTO projectDTO = projectService.searchProjectDetailById(id);
        if (null != projectDTO) {
        	String employeeId = request.getParameter("employeeId");
            int workersId = Integer.parseInt(employeeId);
        	EmployeeDTO employeeDTO = employeeService
                    .searchEmployeeDetailById(workersId);
            if (null != employeeDTO) {
            	
            	Set<EmployeeDTO> employees = new HashSet<EmployeeDTO>();
                employees.add(employeeDTO);
                Set<ProjectDTO> projects = new HashSet<ProjectDTO>();
                projects.add(projectDTO);
                projectDTO.setEmployee(employees);
                employeeDTO.setProject(projects);
                int projectid = projectService
                		.updateProjectDetailById(id, projectDTO);		
                workersId = employeeService.updateEmployeeDetailById
                        (employeeDTO);      
                logger.info("Project" + projectid + "Assigned to" 
                        + employeeId);
            } else {
            	logger.info("NO EMPLOYEE FOUND"); 
			}
         } else {
            logger.info("NO PROJECT FOUND"); 
         }
    }
 
}


/**  
 *  Copyright (c) All rights reserved.
 */
package com.i2i.employeemanagement.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

/**
 *  This class has Attributes of PhoneNumber
 *
 *  @author Priyadharshini Gunasekaran
 *
 *  version JAVA 8
 */
@Entity
@Table(name="project")
public class Project {
	
	@Id
	@Column(name="project_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
    private int id;
	
	@Column(name="project_name")
    private String name;
	
	@Column(name="project_description")
    private String softwareRequirement;	
	
	@Column(name="description")
    private String description;
	
	@Column(name="no_of_members")
    private int noOfMembers;
	
	@ManyToMany(mappedBy="project")
    private Set<Employee> employee;
        
    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }    

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setSoftwareRequirement(String softwareRequirement) {
        this.softwareRequirement = softwareRequirement;
    }

    public String getSoftwareRequirement() {
        return softwareRequirement;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
   
    public void setNoOfMembers(int noOfMembers) {
        this.noOfMembers = noOfMembers;
    }

    public int getNoOfMembers() {
       return noOfMembers;
    }
   
    public void setEmployee(Set<Employee> employee) {
        this.employee = employee;
    } 
 
    public Set<Employee> getEmployee() {
        return employee;
    }
}
 
	                 

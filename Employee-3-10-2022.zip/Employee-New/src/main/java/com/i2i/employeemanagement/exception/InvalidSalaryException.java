    /**  
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
package com.i2i.employeemanagement.exception;

/** 
 *  This class handles the Exceptions
 *
 */ 
public class InvalidSalaryException extends Exception {

     public  InvalidSalaryException(String message) {
         super(message);
     }
}

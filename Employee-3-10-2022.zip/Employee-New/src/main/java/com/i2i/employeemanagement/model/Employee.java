/**  
 *  Copyright (c) All rights reserved.
 */
package com.i2i.employeemanagement.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import java.util.List;

/**
 *  This class has Attributes of Employee
 *
 *  @author Priyadharshini Gunasekaran
 *
 *  version JAVA 8
 */
@Entity
@Table(name="employee")
public class Employee {
	
	@Id
	@Column(name="employee_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
    private int employeeId;
	
	@Column(name="company_name")
    public static String companyName = "Ideas2IT";
	
	@Column(name="employee_name")
    private String employeeName;
	
	@Column(name="email_id")
    private String emailId;	
	
    @Column(name="designation")
    private String designation;  
    
    @Column(name="qualification")
    private String qualification;
    
    @Column(name="salary")
    private double salary;
    
    @Column(name="account_number")
    private String accountNumber; 
    
    @Column(name="ifsc_code")
    private String ifscCode;	
    
    @OneToMany(mappedBy="employee",
    		   cascade=CascadeType.ALL,
    		   fetch=FetchType.EAGER)
    @Fetch(value=FetchMode.SELECT)
    private Set<PhoneNumber> phoneNumbers;
    
    @OneToMany(mappedBy="employee", cascade=CascadeType.ALL,
    		   fetch=FetchType.EAGER)
    @Fetch(value=FetchMode.SELECT)
    private List<Address> address;	
    
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="workplace_id")
    private SeatAllotment seat;
    
    @ManyToMany(cascade=CascadeType.MERGE,
    			fetch=FetchType.EAGER)
    @Fetch(FetchMode.SELECT)
    @JoinTable(name="projectassignment",
    		   joinColumns=@JoinColumn(name="employee_id"),
    		   inverseJoinColumns=@JoinColumn(name="project_id"))
    private Set<Project> project;
    
    public String getCompanyName() {
        return companyName;
    }
    
    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeName() {
        return employeeName;
    }
    
    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public int getEmployeeId() {
        return employeeId;
    }
 
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getEmailId() {
        return emailId;
    }
    
    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDesignation() {
        return designation;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getQualification() {
        return qualification;
    }  

    public void setSalary(double salary) {
        this.salary =  salary * 12;
    } 
    
    public double getSalary() {
        return salary;
    }
   
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

    public String getIfscCode() {
        return ifscCode;
    }    

    public void setSeat(SeatAllotment seat) {
    	this.seat = seat;
	}
	
	public SeatAllotment getSeat() {
        return seat;
	}

    public void setPhoneNumber(Set<PhoneNumber> phoneNumbers) {
    	this.phoneNumbers = phoneNumbers;
    }
    
    public Set<PhoneNumber> getPhoneNumber() {
        return phoneNumbers;
    }

    public void setAddress(List<Address> address) {
    	this.address = address;
    }

    public List<Address> getAddress() {
    	return address;
    }

   public void setProject(Set<Project> project) {
        this.project = project;
    } 
 
    public Set<Project> getProject() {
        return project;
    }
    
}	                 

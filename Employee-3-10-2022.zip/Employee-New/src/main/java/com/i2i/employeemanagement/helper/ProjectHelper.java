/**  
 *  
 *  Copyright (c) All rights reserved.
 *  
 */
package com.i2i.employeemanagement.helper;

import java.util.HashSet;
import java.util.Set;

import com.i2i.employeemanagement.dto.EmployeeDTO;
import com.i2i.employeemanagement.dto.ProjectDTO;
import com.i2i.employeemanagement.helper.EmployeeHelper;
import com.i2i.employeemanagement.model.Employee;
import com.i2i.employeemanagement.model.Project;

/**
 *  This class is used for validation purpose
 * 
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */

public class ProjectHelper {

    /**
     *  This method set project to projectDTO
     *
     *  @param project change project to projectDTO 
     *
     *  @returns ProjectDTO
     */
    public static ProjectDTO convertProjectIntoProjectDto(Project project, boolean flag) {
		ProjectDTO projectDTO = new ProjectDTO();
		projectDTO.setName(project.getName());
		projectDTO.setId(project.getId());
        projectDTO.setSoftwareRequirement(project.getSoftwareRequirement());
        projectDTO.setDescription(project.getDescription());
        projectDTO.setNoOfMembers(project.getNoOfMembers());
        Set<EmployeeDTO> employeeDTOs = new HashSet<EmployeeDTO>();
        Set<Employee> employees =  project.getEmployee();
        
        if (null != employees && flag) {
            for (Employee employee : employees) {
                employeeDTOs.add(EmployeeHelper.convertEmployeeIntoEmployeeDto(employee, false));
            }
            projectDTO.setEmployee(employeeDTOs);   
    	    
    	}
    	return projectDTO;
    	
    	
    }
    
    /**
     *  This method set projectDTO to project
     *
     *  @param projectDTO change projectDTO to project 
     *
     *  @returns Employee
     */
    public static Project convertProjectDtoIntoProject(ProjectDTO projectDTO, boolean flag) {
	    Project project = new Project();
		project.setName(projectDTO.getName());
		System.out.println("dtoid***" + projectDTO.getId());
		project.setId(projectDTO.getId());
        project.setSoftwareRequirement(projectDTO.getSoftwareRequirement());
        project.setDescription(projectDTO.getDescription());
        project.setNoOfMembers(projectDTO.getNoOfMembers());
        Set<Employee> employees = new HashSet<Employee>();
        Set<EmployeeDTO> employeeDTOs =  projectDTO.getEmployee();
        
        if (null != employeeDTOs && flag) {
            for (EmployeeDTO employeeDTO : employeeDTOs) {
                employees.add(EmployeeHelper.convertEmployeeDtoIntoEmployee(employeeDTO, false));
            }
            project.setEmployee(employees);   
    	    
    	}
    	return project;
    }
}

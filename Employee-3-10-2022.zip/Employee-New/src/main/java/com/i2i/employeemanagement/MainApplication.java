/**  
 *  
 *  Copyright (c) All rights reserved.
 *  
 */
package com.i2i.employeemanagement;

import org.apache.log4j.PropertyConfigurator;

import com.i2i.employeemanagement.controller.EmployeeController;
import com.i2i.employeemanagement.controller.ProjectController;

/**
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
public class MainApplication {

    /**
     *  Control Overall CRUD operations
     *
     *  @param args accepts single argument of type String Array
     *  
     *  @author Priyadharshini Gunasekaran
     *
     *  version java 8
     *
     *  Date: 26/08/2022
     */ 
       
    public static void main(String args[]) {
        String path = "/home/ubuntu/Desktop/src/log4j/log4j.properties";
        PropertyConfigurator.configure(path);
        //menu();
    }
    
    //menu
    /*public static void menu() {
        Scanner scanner = new Scanner(System.in);
        EmployeeController employeeController = new EmployeeController(); 
        ProjectController projectController = new ProjectController();
        int choice ;
        do {
        System.out.println("ENTER CHOICE [1-2]");
        System.out.println(" 1. EMPLOYEE ");
        System.out.println(" 2. PROJECT ");
        choice = Integer.parseInt(scanner.nextLine());
        switch (choice) {
        	case 1: 
        		employeeController.getEmployeePortal();
                break;

            case 2:
                projectController.getProjectPortal();
                break;

			default:
                System.out.println("Enter Numeric Value");
        }
		}while(choice != 2);
    
    }*/

}


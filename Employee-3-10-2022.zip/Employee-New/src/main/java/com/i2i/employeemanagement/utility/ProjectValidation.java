/*  
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
package com.i2i.employeemanagement.utility;

import java.util.regex.Pattern;
import java.util.Scanner;
import java.lang.String;
/**
 * This class is used for validation purpose
 */
public class ProjectValidation  {

    /*
     * This method validate the project name 
     *
     * @param name is to validate project name
     *
     * @return valid project name
     *
     */
    public static boolean isValidProjectName(String name) {
        boolean isValid = false;
        String projectNameRegex = "^[A-Za-z]+$";
        Pattern pattern = Pattern.compile(projectNameRegex); 
        if (pattern.matcher(name).matches()) {
            isValid = true;
        } 
        return isValid;
    }     

    /*
     * This method validate the softwareRequirement
     *
     * @param softwareRequirement is to validate the softwareRequirement
     *
     * @return  Valid softwareRequirement
     * 
     */
    public static boolean isValidSoftwareRequirement(String softwareRequirement) {
        boolean isValid = false;
        String softwareRequirementRegex = "^[A-Za-z]+$";
        Pattern pattern = Pattern.compile(softwareRequirementRegex); 
        if (pattern.matcher(softwareRequirement).matches()) {
            isValid = true;
        } 
        return isValid;
    }
    
    /*
     * This method validate the description 
     *
     * @param description is to validate description
     *
     * @return Valid description
     * 
     */
    public static boolean isValidDescription(String description) {
        boolean isValid = false;
        String descriptionRegex = "^[A-Za-z]+$";
        Pattern pattern = Pattern.compile(descriptionRegex); 
        if (pattern.matcher(description).matches()) {
            isValid = true;
        } 
        return isValid; 
    } 
    
    /*
     * This method validate the noOfMembers
     *
     * @param noOfMembers is to validate the noOfMembers
     *
     * @return valid noOfMembers
     *
     */
    public static boolean isValidNoOfMember(String noOfMembers) {
        boolean isValid = false;
        String noOfMemberRegex = "^[0-9]+$";
        Pattern pattern = Pattern.compile(noOfMemberRegex);
        if (pattern.matcher(noOfMembers).matches()) {
            isValid = true;
        } 
        return isValid; 
    } 
    
}




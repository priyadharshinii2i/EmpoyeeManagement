/**  
 *  Copyright (c) All rights reserved.
 */
package com.i2i.employeemanagement.model;

import java.lang.StringBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *  This class has Attributes of Address
 *
 *  @author Priyadharshini Gunasekaran
 *
 *  version JAVA 8
 */
@Entity
public class Address {
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@Column(name="door_no")
	private int doorNumber;
	@Column(name="street_name")
	private String streetName;
	@Column(name="city")
    private String city;
	@Column(name="pincode")
    private long pincode;

    public void setId(int id) {
        this.id = id;
    }
    
    public int getId() {
        return id;
    }
    
    public void setDoorNumber(int doorNumber) {
		this.doorNumber = doorNumber;
	}

    public int getDoorNumber() {
		return doorNumber;
    }

    public void setStreetName(String streetName) {
    	this.streetName = streetName;
    }

	public String getStreetName() {
		return streetName;
    }

    public void setCity(String city) {
    	this.city = city;
    }

	public String getCity() {
		return city;
    }

	public void setPincode(long pincode) {
    	this.pincode = pincode ;
    }

	public long getPincode() {
		return pincode;
    }
    
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();    
        return stringBuilder.append("\n DoorNUmber:").append(getDoorNumber()).append("\n City:").append(getCity())
                .append("\n StreetName:").append(getStreetName()).append("\n Pincode:").append(getPincode()).toString();
    }
}

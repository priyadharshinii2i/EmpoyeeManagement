/**  
 *  Copyright (c) All rights reserved.
 */
package com.i2i.employeemanagement.dao;

import java.sql.SQLException;
import java.util.Map;

import com.i2i.employeemanagement.model.Employee;
import com.i2i.employeemanagement.singleton.Singleton;

/**
 *  This class used to create, search, update, display and delete
 *  Employee object.
 *
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
public interface EmployeeDAO {

    /** 
     *  Used to add employee  
     *
     *  @param employee to be added 
     *
     *  @param EmployeeId to be added
     *
     *  @return created EmployeeId
     */ 
    public int insertEmployee(int EmployeeId, Employee employee);

    /**
     *  Used to search Employee
     * 
     *  @param EmployeeId used to find employee
     *  
     *  @return employee 
     *  
     */
    public Employee selectEmployeeDetailById(int EmployeeId);

    /** 
     *  Used to update employee 
     *
     *  @param employee is to update employee
     *
     *  @return updated EmployeeId 
     */
    public int modifyEmployeeDetailById(Employee employee);

    /** 
     *  Used to display employee 
     *
     *  @return employee
     */
    public Map<Integer, Employee>displayEmployeeDetail();

    /** 
     *  Remove employee
     *
     *  @param EmployeeId is to find employee
     *
     *  @return deleted EmployeeId        
     */
    public int removeEmployeeDetailById(int EmployeeId);
}

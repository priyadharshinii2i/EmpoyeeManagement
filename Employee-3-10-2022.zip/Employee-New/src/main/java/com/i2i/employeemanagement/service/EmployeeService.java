/**  
 *  
 *  Copyright (c) All rights reserved.
 *  
 */
package com.i2i.employeemanagement.service;

import java.util.Map;

import com.i2i.employeemanagement.dto.EmployeeDTO;

/**
 *  This class used to create, search, update, display, delete
 *  Employee 
 *
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
public interface EmployeeService {

    /** 
     *  Used to add employee  
     *
     *  @param employeeDTO to be added 
     *
     *  @param employeeId to be added
     *
     *  @return employeeId created
     */ 
    public int addEmployee(int employeeId, EmployeeDTO employeeDTO);
    
    /**
     *  Used to search Employee
     * 
     *  @param employeeId used to find employee
     *   
     *  @return employeeDTO 
     */
    public EmployeeDTO searchEmployeeDetailById(int employeeId);
    
    /** 
     *  Used to update employee 
     *
     *  @param employeeDTO is to update Employee
     *
     *  @return employeeId Updated
     */
    public int updateEmployeeDetailById(EmployeeDTO employeeDTO);

    /** 
     *
     *  Used to display employee 
     *
     *  @return employeeDTO
     */
    public Map<Integer, EmployeeDTO> showEmployeeDetail();

    /** 
     *  Remove employee 
     *
     *  @param employeeId is to find employee
     *
     *  @return deleted employeeId  
     */
    public int deleteEmployeeDetailById(int employeeId);
}



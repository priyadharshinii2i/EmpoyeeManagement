/*  
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
package com.i2i.employeemanagement.service.impl;

import java.util.HashMap;
import java.util.Map;

import com.i2i.employeemanagement.dao.ProjectDAO;
import com.i2i.employeemanagement.dao.impl.ProjectDaoImpl;
import com.i2i.employeemanagement.dto.ProjectDTO;
import com.i2i.employeemanagement.helper.ProjectHelper;
import com.i2i.employeemanagement.model.Project;
import com.i2i.employeemanagement.service.ProjectService;

/**
 *  This class used to create, search, update, display, delete
 *  project
 *
 */
public class ProjectServiceImpl implements ProjectService {

    private ProjectDAO projectDAO = new ProjectDaoImpl();
    
    /** 
     *  Used to add project  
     *
     *  @param project to be added 
     *
     *  @param employeeId to be added
     *
     *  @return created employeeId
     */  
    public int addProject(int id, ProjectDTO projectDTO) {
        return projectDAO.insertProject(id, ProjectHelper
                .convertProjectDtoIntoProject(projectDTO, false));
    }

    /**
     *  Used to search detail 
     * 
     *  @param employeeId used to find project
     *  
     *  @return project 
     *  
     */
    public ProjectDTO searchProjectDetailById(int id) {
        Project project = projectDAO.selectProjectDetailById(id);
        if (null != project) {            
            return ProjectHelper.convertProjectIntoProjectDto(project, true);
        } else {
            return null;
        }
        
    }     
    
    /** 
     *  Used to update project 
     *
     *  @param emlopyeeId is to find project
     *
     *  @param phoneNumber is to update phoneNumber
     *
     *  @return updated employeeId 
     */
    public int updateProjectDetailById(int id,ProjectDTO projectDTO) {
        System.out.println("service id****" + projectDTO.getId());
        return projectDAO.modifyProjectDetailById(id, ProjectHelper
                .convertProjectDtoIntoProject(projectDTO, true));
    }     

    /** 
     *  Used to display project 
     *
     *  @return projects detail
     */
    public Map<Integer, ProjectDTO> showProjectDetail() {
        Map<Integer, Project> project = projectDAO.displayProjectDetail();
        Map<Integer, ProjectDTO> projectDTO = new HashMap<>();
        for (Map.Entry<Integer,Project> projectDto : project.entrySet())
            projectDTO.put(projectDto.getKey(), ProjectHelper
                    .convertProjectIntoProjectDto(projectDto.getValue(), true));
        return projectDTO;
    }
    
    /** 
     *  Remove project detail
     *
     *  @param employeeId is to find project
     *
     *  @return deleted employeeId        
     */
    public int deleteProjectDetailById(int id) {
        return projectDAO.removeProjectDetailById(id);    
    }
    
    public void assignEmployeeToProject(int employeeId, int projectId) {
        projectDAO.assignEmployeeToProject(employeeId, projectId);
    }
    
}

/**  
 *  
 *  Copyright (c) All rights reserved.
 *  
 */
package com.i2i.employeemanagement.helper;


import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;
import java.util.Set;

import com.i2i.employeemanagement.dto.EmployeeDTO;
import com.i2i.employeemanagement.dto.ProjectDTO;
import com.i2i.employeemanagement.helper.ProjectHelper;
import com.i2i.employeemanagement.model.Employee;
import com.i2i.employeemanagement.model.Project;

/**
 *  This class is used for validation purpose
 * 
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */

public class EmployeeHelper {

    /**
     *  This method set employee to employeeDTO
     *
     *  @param employee change employee to employeeDTO 
     *
     *  @returns EmployeeDTO
     */
    public static EmployeeDTO convertEmployeeIntoEmployeeDto(Employee employee, boolean flag) {
		EmployeeDTO employeeDTO = new EmployeeDTO();
		employeeDTO.setEmployeeName(employee.getEmployeeName());
		employeeDTO.setEmployeeId(employee.getEmployeeId());
		employeeDTO.setEmailId(employee.getEmailId());
		employeeDTO.setAddress(employee.getAddress());
        employeeDTO.setSeat(employee.getSeat());
        employeeDTO.setSalary(employee.getSalary());
        employeeDTO.setPhoneNumber(employee.getPhoneNumber());
		employeeDTO.setAccountNumber(employee.getAccountNumber());
		employeeDTO.setIfscCode(employee.getIfscCode());
		employeeDTO.setQualification(employee.getQualification());
        employeeDTO.setDesignation(employee.getDesignation());
        Set<ProjectDTO> projectDTOs = new HashSet<ProjectDTO>();
        Set<Project> projects = employee.getProject();
        if (null != projects && flag) {
            for (Project project : projects) {
                projectDTOs.add(ProjectHelper.convertProjectIntoProjectDto(project, false));
            }
            employeeDTO.setProject(projectDTOs);
        }
    	return employeeDTO;
    }
    
    /**
     *  This method set employeeDTO to employee
     *
     *  @param employeeDTO change employeeDTO to employee 
     *
     *  @returns Employee
     */
    public static Employee convertEmployeeDtoIntoEmployee(EmployeeDTO employeeDTO, boolean flag) {
		Employee employee = new Employee();
		employee.setEmployeeName(employeeDTO.getEmployeeName());
		employee.setEmployeeId(employeeDTO.getEmployeeId());
		employee.setEmailId(employeeDTO.getEmailId());
		employee.setAddress(employeeDTO.getAddress());
		employee.setSalary(employeeDTO.getSalary());
        employee.setSeat(employeeDTO.getSeat());
        employee.setPhoneNumber(employeeDTO.getPhoneNumber());
		employee.setAccountNumber(employeeDTO.getAccountNumber());
		employee.setIfscCode(employeeDTO.getIfscCode());
		employee.setQualification(employeeDTO.getQualification());
        employee.setDesignation(employeeDTO.getDesignation());
        
        Set<Project> projects = new HashSet<Project>();
        Set<ProjectDTO> projectDTOs = employeeDTO.getProject();
        if (null != projectDTOs && flag) {
            for (ProjectDTO projectDTO : projectDTOs) {
                projects.add(ProjectHelper.convertProjectDtoIntoProject(projectDTO, false));
            }
            employee.setProject(projects);
        }
    	return employee;
    }
}

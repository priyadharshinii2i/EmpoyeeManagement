/**  
 *  Copyright (c) All rights reserved.
 */

package com.i2i.employeemanagement.dto;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.lang.StringBuilder;

import com.i2i.employeemanagement.dto.EmployeeDTO;

/**
 *  This class has Attributes of project
 *
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
public class ProjectDTO {

    private int id;
    private String name;
    private String softwareRequirement;	
    private String description;
    private int noOfMembers;
    private Set<EmployeeDTO> employee;

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
 
    public void setSoftwareRequirement(String softwareRequirement) {
        this.softwareRequirement = softwareRequirement;
    }

    public String getSoftwareRequirement() {
        return softwareRequirement;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
   
    public void setNoOfMembers(int noOfMembers) {
        this.noOfMembers = noOfMembers;
    }

    public int getNoOfMembers() {
        return noOfMembers;
    }
 
    public void setEmployee(Set<EmployeeDTO> employee) {
        this.employee = employee;
    } 
 
    public Set<EmployeeDTO> getEmployee() {
        return employee;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
    	return (stringBuilder.append("Id").append(getId())
    	        .append("\n Name :").append(getName())
    	        .append("\nSoftwareRequirement:").append(getSoftwareRequirement())
    	        .append("\nDescription:").append(getDescription())
    	        .append("\nNoOfMembers:").append(getNoOfMembers())
    	        .append("\nAssignProjectToEmployee:").append(getEmployee())
    	        .toString());
    	      
    }

}    


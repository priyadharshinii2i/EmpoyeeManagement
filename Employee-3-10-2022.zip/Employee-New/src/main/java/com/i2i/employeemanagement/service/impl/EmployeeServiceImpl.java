/**  
 *  
 *  Copyright (c) All rights reserved.
 *  
 */
package com.i2i.employeemanagement.service.impl;

import java.util.HashMap;
import java.util.Map;

import com.i2i.employeemanagement.dao.EmployeeDAO;
import com.i2i.employeemanagement.dao.impl.EmployeeDaoImpl;
import com.i2i.employeemanagement.dto.EmployeeDTO;
import com.i2i.employeemanagement.helper.EmployeeHelper;
import com.i2i.employeemanagement.model.Employee;
import com.i2i.employeemanagement.service.EmployeeService;

/**
 *  This class used to create, search, update, display, delete
 *  Employee
 *
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 *
 */
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeDAO employeeDAO = new EmployeeDaoImpl();
    
    /** 
     *  Used to add employee  
     *
     *  @param employeeDTO  to be added 
     *
     *  @return employeeId created
     */  
    public int addEmployee(int employeeId, EmployeeDTO employeeDTO) {
        
        return employeeDAO.insertEmployee(employeeId, EmployeeHelper
                .convertEmployeeDtoIntoEmployee(employeeDTO, false));  
        
    }

    /**
     *  Used to search detail 
     * 
     *  @param employeeId used to find employee
     *  
     *  @return employeeDTO 
     *  
     */
    public EmployeeDTO searchEmployeeDetailById(int employeeId) {
        Employee employee = employeeDAO.selectEmployeeDetailById(employeeId);
        if (null != employee) {            
            return EmployeeHelper.convertEmployeeIntoEmployeeDto(employee, true);
        } else {
            return null;
        }
    }     
    
    /** 
     *  Used to update employee 
     *
     *  @param employeeDTO is to update Employee
     *
     *  @return employeeId Updated
     */
    public int updateEmployeeDetailById(EmployeeDTO employeeDTO) {
        return employeeDAO.modifyEmployeeDetailById(EmployeeHelper
                .convertEmployeeDtoIntoEmployee(employeeDTO, true));
    }     

    /** 
     *  Used to display employee 
     *
     *  @return employeeDTO
     */
    public Map<Integer, EmployeeDTO> showEmployeeDetail() {
        Map<Integer, Employee> employee = employeeDAO.displayEmployeeDetail();
        Map<Integer, EmployeeDTO> employeeDTO = new HashMap<>();
        for (Map.Entry<Integer,Employee> employeeDto : employee.entrySet())
            employeeDTO.put(employeeDto.getKey(), EmployeeHelper
                    .convertEmployeeIntoEmployeeDto(employeeDto.getValue(), true));
            return employeeDTO;
    }
    /** 
     *  Remove employee detail
     *
     *  @param employeeId is to find employee
     *
     *  @return deleted employeeId        
     */
    public int deleteEmployeeDetailById(int employeeId) {
        return employeeDAO.removeEmployeeDetailById(employeeId);    
    }    
}

package com.i2i.employeemanagement.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Authentication extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("user-id");
		String password = request.getParameter("password");

		if(username.equals("admin") && password.equals("password")) {
			HttpSession session = request.getSession();
		    session.setAttribute("user-id", username);
			session.setAttribute("password", password);
			RequestDispatcher requestdispatcher = request.getRequestDispatcher("Home.jsp");
			requestdispatcher.forward(request, response);
		} else {
			RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
			PrintWriter out = response.getWriter();
            out.println("<font color=red>Password is wrong.</font>");
            rd.include(request, response);
		};
	}

}

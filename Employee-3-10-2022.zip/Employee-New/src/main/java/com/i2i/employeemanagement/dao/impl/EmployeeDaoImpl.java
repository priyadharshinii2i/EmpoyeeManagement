/**  
 *  
 *  Copyright (c) All rights reserved.
 *  
 */
package com.i2i.employeemanagement.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
//import java.sql.Connection;
//import java.sql.SQLException;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
import org.hibernate.HibernateException;
import org.hibernate.Transaction;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.i2i.employeemanagement.model.Address;
import com.i2i.employeemanagement.model.Employee;
import com.i2i.employeemanagement.model.PhoneNumber;
import com.i2i.employeemanagement.model.SeatAllotment;
import com.i2i.employeemanagement.model.PhoneNumber;
import com.i2i.employeemanagement.model.Project;
import com.i2i.employeemanagement.dao.EmployeeDAO;
import com.i2i.employeemanagement.dao.impl.ProjectDaoImpl;
import com.i2i.employeemanagement.singleton.Singleton;
import com.i2i.employeemanagement.utility.EmployeeUtility;

/**
 *  This class used to create, search, update, display and delete
 *  Employee object.
 *
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
public class EmployeeDaoImpl implements EmployeeDAO{

   Singleton singleton = Singleton.getInstance();
   SessionFactory sessionFactory = singleton.getSessionFactory();
   Session session = null;
   Transaction transaction = null;
   
   /*private static Map<Integer, Employee> employees = new HashMap<Integer, 
                                                               Employee>();*/
  /** 
   *  Used to insert employee 
   *
   *  @param employee to be added
   *  
   *  @param employeeId to be added
   *
   *  @return created employeeId
   */
    public int insertEmployee(int employeeId, Employee employee) {
        
        session = sessionFactory.openSession();
        try {
            transaction = session.beginTransaction();
            session.save(employee);
            transaction.commit();
        } catch (HibernateException hibernateException) {
            hibernateException.printStackTrace();
        }
        finally {
            session.close();
        }
        return employee.getEmployeeId();
    }

    /**
     *  Used to select Employee
     * 
     *  @param employeeId is to find employee
     *  
     *  @return employee
     *  
     */
    public Employee selectEmployeeDetailById(int employeeId) {
        Employee employee = null;
        session = sessionFactory.openSession();
        try {
            transaction = session.beginTransaction();
            employee = session.get(Employee.class, employeeId);
        } catch (HibernateException hibernateException){
            hibernateException.printStackTrace();
        }
        finally {
            session.close();
        }
        return employee;       
            
    }

    /** 
     *  Used to update employee
     *
     *  @param employee to update employee
     *
     *  @return updated employeeId 
     */
    public int modifyEmployeeDetailById(Employee employee) {
        session = sessionFactory.openSession();
        try {
            transaction = session.beginTransaction();
            session.update(employee);
            transaction.commit();
        } catch (HibernateException hibernateException) {
            hibernateException.printStackTrace();
        }
        finally {
            session.close();
        }
        return employee.getEmployeeId();
        
        
    }
     
    /** 
     *  Used to display employee 
     *
     *  @return employee
     */
    public Map<Integer, Employee> displayEmployeeDetail() {
    
        Map<Integer, Employee> employeeMap = new HashMap();
        
        session = sessionFactory.openSession();
        try {
            transaction = session.beginTransaction();
            String employeeHql = "FROM Employee";
            Query employeeQuery = session.createQuery(employeeHql);
            List<Employee> employees = employeeQuery.list();
            for (Employee employeeDetails : employees) {
                employeeMap.put( employeeDetails.getEmployeeId(), employeeDetails);
            }
        } catch (HibernateException hibernateException) {  
            hibernateException.printStackTrace();
        }
        
        finally {
            session.close();
        }
          
        return employeeMap;   
    }    

    /** 
     *  Remove employee 
     *
     *  @param employeeId is to find employee
     *
     *  @return deleted employeeId 
     */
    public int removeEmployeeDetailById(int employeeId) {

        session = sessionFactory.openSession();
        Employee employee = null;
        try {
            transaction = session.beginTransaction();
            employee = session.get(Employee.class, employeeId);
            session.delete(employee);
            transaction.commit();
        } catch (HibernateException hibernateException) {
            hibernateException.printStackTrace();
        } finally {
            session.close();
        }
        return employee.getEmployeeId();
    }

    public PhoneNumber employeePhoneNumber() {
        session = sessionFactory.openSession();
        PhoneNumber phoneNumber = new PhoneNumber();
        try {
            transaction = session.beginTransaction();
            String phoneNumberHQl = "FROM PhoneNumber";
            Query phoneNumberQuery = session.createQuery(phoneNumberHQl);


        } catch (HibernateException hibernateExceptionException) {
            hibernateExceptionException.printStackTrace();
        }
        return phoneNumber;
    }
}

/** 
 *   Copyright (c) All rights reserved.
 */
package com.i2i.employeemanagement.controller;

import com.i2i.employeemanagement.dto.EmployeeDTO;
import com.i2i.employeemanagement.model.Address;
import com.i2i.employeemanagement.model.PhoneNumber;
import com.i2i.employeemanagement.model.SeatAllotment;
import com.i2i.employeemanagement.service.EmployeeService;
import com.i2i.employeemanagement.service.ProjectService;
import com.i2i.employeemanagement.service.impl.EmployeeServiceImpl;
import com.i2i.employeemanagement.service.impl.ProjectServiceImpl;
import com.i2i.employeemanagement.utility.EmployeeUtility;

import org.apache.log4j.Logger;
import java.io.IOException;


import java.io.PrintWriter;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;

/**
 *
 *  This class used to create, search, update, display and delete Employee
 *
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
public class EmployeeController extends HttpServlet {

    EmployeeService employeeService = new EmployeeServiceImpl();
    ProjectService projectService = new ProjectServiceImpl();
    private static Logger logger = Logger.getLogger(EmployeeController.class);
    
    /**
     *
     * <p>
     *   Direct the user to Employee Portal.  
     * <p>
     *
     *  Direct the user to Insert, search, Update,
     *  Display and Delete Employee detail
     *
     */

   /* public void getEmployeePortal() {
        int choice = 0; 

        System.out.println(" *** WELCOME TO EMPLOYEE PORTAL *** ");
        StringBuilder stringBuilder = new StringBuilder();
        do {     
            System.out.println("\nPress- 1. To Insert detail of Employee ");
            System.out.println("Press- 2. To Search detail of Employee");
            System.out.println("Press- 3. To Update detail of Employee");
            System.out.println("Press- 4. To Display detail of Employee"); 
            System.out.println("Press- 5. To Delete detail of Employee");
            System.out.println("Press- 6. To Exit");
            try {
                choice = Integer.parseInt(scanner.nextLine());
                switch (choice) {
		            case 1:
		                createEmployee();
		                break;
	 
		            case 2:
		                searchEmployeeDetail();
		                break;

		            case 3:
		                updateEmployeeDetail();
                        System.out.println("BACK TO EMPLOYEE PORTAL");
		                break;
		   
		            case 4:
		                showEmployeeDetail();
                        System.out.println("BACK TO EMPLOYEE PORTAL");
		                break;

		            case 5:
		                deleteEmployee();
		                break;

		            case 6:
		                System.out.println("BACK TO MAIN MENU");
		                MainApplication.menu();
		                break;
		        
		            default: 
		                System.out.println("ENTER NUMERIC OPTION");
                }
            } catch (NumberFormatException numberFormatException) {
                System.out.println("ENTER NUMERIC OPTION (1-6)"); 
            }
        } while (choice != 6);
   
    }*/

    /**
     *  create new Emlpoyee
     */
    /*public void createEmployee() {
        boolean isValid = false;
        String employeeQualification;	
        String employeeAccountNumber;
        String employeeIfscCode;
        String employeeDesignation;
        int createdId;

        Set<PhoneNumber> phoneNumbers = new HashSet<PhoneNumber>();
        List<Address> employeeAddress = new ArrayList<Address>();
        EmployeeDTO employeeDTO = new EmployeeDTO();
        System.out.println("Company Name:" + employeeDTO.companyName);  

        do{ 
            System.out.println("\nEnter Name of the Employee :");
            String employeeName = scanner.nextLine();
            if (!(employeeName.trim().isEmpty())) { 
                if (Validation.isValidName(employeeName)){
                    employeeDTO.setEmployeeName(employeeName);
                    isValid = true;
                } else {
                    logger.warn("Enter Valid Name of employee");
                }
            } 
        } while (!isValid);  

        employeeDTO.setEmailId(EmployeeUtility.employeeEmailId(employeeDTO
                .getEmployeeName(), EmployeeUtility.generateEmployeeId()));
        phoneNumbers.add(getPhoneNumber(employeeDTO));
        employeeDTO.setPhoneNumber(phoneNumbers);
        isValid = false;
      
        do{ 
            System.out.println("\nEnter Qualification of the Employee");
            employeeQualification = scanner.nextLine();
            if (!(employeeQualification.trim().isEmpty())) { 
                if (Validation.isValidQualification(employeeQualification)) {
                    employeeDTO.setQualification(employeeQualification );
                    isValid = true;
                } else {
                    logger.warn("Enter Valid Qualification of employee");
                }
            } 
        } while (!isValid);
        isValid = false;  

        do{
            System.out.println("\nEnter Employee Salary - salary should 25000 "
                    + " or above 25000 ");
            try {
                String employeeSalary = scanner.nextLine();
                if (!(employeeSalary.trim().isEmpty())) {
                    if (Validation.isValidSalary(employeeSalary)) {
                        double pay = Double.parseDouble(employeeSalary);
                        double salary = checkSalary(pay);
	                    employeeDTO.setSalary(pay);
                        isValid = true;
                    } else {	
                        logger.warn("Salary should 25000 or above 25000");
                        isValid = false;
                    }
                } else {
                    isValid = false;
                    logger.warn("Enter valid Salary");
                }
            } catch (InvalidSalaryException invalidSalaryException) { 
		        logger.warn("NOT A VALID SALARY" + invalidSalaryException
                        .getMessage());   
            }
        } while (!isValid);
        isValid = false;         

        do{  
            System.out.println("\nEnter Designation of the Employee:");
            employeeDesignation = scanner.nextLine();
            if (!(employeeDesignation.trim().isEmpty()) ) {
                if (Validation.isValidDesignation(employeeDesignation)) {
                    employeeDTO.setDesignation(employeeDesignation); 
                    isValid = true;
                } else {
                    logger.warn("Enter Valid Designation of employee");
                }
            } 
        } while (!isValid);
        System.out.println("\nEnter employee AccountNumber - AccountNumber -" 
                + " Should be 14 digits ");
        
        do {
            employeeAccountNumber = scanner.nextLine();
            if (Validation.isValidAccountNumber(employeeAccountNumber)) {
                employeeDTO.setAccountNumber(employeeAccountNumber);
            } else {
                logger.warn("Enter Valid AccountNumber" 
                        + "-Account Number Should be 14 digits");
            }
        } while (!Validation.isValidAccountNumber(employeeAccountNumber));
        isValid = false;
        
        System.out.println("\nEnter employee IFSC code: ");
        do{  
            employeeIfscCode = scanner.nextLine();
            if ( !(employeeIfscCode.trim().isEmpty()) ) {
                if (Validation.isValidIfscCode(employeeIfscCode)) {
                    employeeDTO.setIfscCode(employeeIfscCode); 
                    isValid = true;
                } else {
                    logger.warn("Enter Valid IFSC Code");
                }
            } 
        } while (!isValid);
       
        SeatAllotment seat = seatAllotment();
        Address addresses = getAddress();
        employeeAddress.add(addresses);
        employeeDTO.setAddress(employeeAddress);        
        employeeDTO.setPhoneNumber(phoneNumbers);
        employeeDTO.setSeat(seat);
        createdId = employeeService.addEmployee(employeeDTO.getEmployeeId(),
                employeeDTO);
        logger.info("\nEMPLOYEE ID " + createdId + " CREATED"); 
    } */     

    /**
     *  Search detail from the Employee
     */
   /* public void searchEmployeeDetail() {
        int choice = 0;
        System.out.println("SEARCH PARTICULAR DETAIL OF EMPLOYEE");
        try {
            System.out.println("Enter Employee ID:"); 
            int employeeId = Integer.parseInt(scanner.nextLine());
            EmployeeDTO employeeDTO = employeeService
                    .searchEmployeeDetailById(employeeId);
            if (null != employeeDTO) {
                do {
                    System.out.println("\nPRESS BELOW GIVEN NUMBER [1-5]");
                    System.out.println("1.NAME");
                    System.out.println("2.EMAIL-ID");
                    System.out.println("3.DESIGNATION");
		            System.out.println("4.QUALIFICATION");
		            System.out.println("5.ADDRESS");
		            System.out.println("6.PHONE NUMBER");
		            System.out.println("7.WORKPLACE");
		            System.out.println("8.SALARY");
		            System.out.println("9.ACCOUNT NUMBER");
		            System.out.println("10.IFSC CODE");
		            System.out.println("11.EXIT");
		            Set<PhoneNumber> phoneNumbers = employeeDTO
                                		.getPhoneNumber();
                    List<Address> addresses = employeeDTO.getAddress();
                    SeatAllotment seat = new SeatAllotment();
                    try {
		                choice =  Integer.parseInt(scanner.nextLine());
		                switch (choice) {
                            case 1: 
                                System.out.println("\nEmployee Name :"
                                        + employeeDTO.getEmployeeName());
         						break;
         						
				            case 2:
				                System.out.println("\nEmployee Email-ID :" + employeeDTO.getEmailId());
				                break;

				            case 3: 
				                System.out.println("\nEmployee Designation :"
                                        + employeeDTO.getDesignation());
				                break;
				                
				            case 4: 
				                System.out.println("\nEmployee Qualification :"
                                        + employeeDTO.getQualification());
				                break;
				               
				            case 5:  
				                List<Address> employeeAddress = employeeDTO.getAddress();
                                for(Address address : employeeAddress) 
                                    System.out.println(address);
				                break;   
				            
				            case 6:
				                Set<PhoneNumber> employeePhoneNumber = employeeDTO.getPhoneNumber();
                                for(PhoneNumber phoneNumber : employeePhoneNumber) 
                                    System.out.println(phoneNumber);
				                break; 

				            case 7:
				                SeatAllotment seatNumber = employeeDTO.getSeat();
				                if (seatNumber.getFirstFloorSeatNumber() == null) {
				                  System.out.println("\nSEAT NUMBER :" + seatNumber.getSecondFloorSeatNumber());
				                } else { 
				                  System.out.println("\nSEAT NUMBER :" + seatNumber.getFirstFloorSeatNumber()); 
				                }
				                System.out.println("FLOOR NUMBER :" + seatNumber.getFloorNumber());
				                System.out.println("BACK TO EMPLOYEE PORTAL");
				                break;
				                
				            case 8:
				                System.out.println("\n SALARY :" + employeeDTO.getSalary());
				                break;
				                
				            case 9:
				                System.out.println("\n ACCOUNT NUMBER :" + employeeDTO.getAccountNumber());
				                break;
				            
				            case 10:
				                System.out.println("\n IFSC CODE :" + employeeDTO.getIfscCode());
				                break;
				                
				            case 11:
				                System.out.println("BACK TO MAIN");
				                break;
				            
				            default:
				                System.out.println("ENTER NUMERIC OPTION [1-5]");
				       } 
		            } catch (NumberFormatException numberFormatException) {
		                System.out.println("ENTER NUMERIC OPTION [1- 5]");
		            } 
		          
                } while (choice != 11);   
            } else {
                logger.info("Employee Not Found");
            }   
        } catch (NumberFormatException numberFormatException) {
            logger.warn("Enter Valid EmployeeID");
        }
    } */
    
    /** 
     *  Update employee detail 
     */
    /*public void updateEmployeeDetail() {
        int choice = 0;
        boolean isEqual = false;

        System.out.println("UPDATE PARTICULAR DETAIL OF EMPLOYEE");
        try {
            System.out.println("Enter Employee ID:"); 
            int employeeId = Integer.parseInt(scanner.nextLine());
            EmployeeDTO employeeDTO = employeeService
                    .searchEmployeeDetailById(employeeId);
               System.out.println("Employee Name:"+ employeeDTO
										.getEmployeeName());
            if (null != employeeDTO) {
                do {
		            System.out.println("\nPRESS BELOW GIVEN NUMBER [1-5]");
		            System.out.println("1.DESIGNATION");
		            System.out.println("2.QUALIFICATION");
		            System.out.println("3.PHONE NUMBER");
                    System.out.println("4.ADDRESS");
		            System.out.println("5.EXIT");
		            try {
		                choice = Integer.parseInt(scanner.nextLine());
				        switch (choice) {
							case 1:
								System.out.println("Enter Employee Designation:");
								String employeeDesignation = scanner.nextLine(); 
                                do {
                                    if (!(employeeDesignation.trim().isEmpty()) ) {
                                        if (Validation.isValidDesignation(employeeDesignation)) {
				                            if ((employeeDTO.getDesignation()).equals(employeeDesignation)) {
				                                System.out.println("This Designation Already Existed");
				                                 isEqual = true;
				                            } else {
				                                employeeDTO.setDesignation(employeeDesignation);
                                            }
                                        } else {
                                            logger.warn("Enter Valid Designation of employee");
                                        }
                                    }
				                } while (isEqual);
				                int updateEmployee = employeeService
                                        .updateEmployeeDetailById(employeeDTO);
				                logger.info("Employee" + updateEmployee 
                                        +"Updated");
								break;

							case 2:
							    System.out.println("Enter Qualification");
							    String qualification = scanner.nextLine();
							    do {
							        if ((employeeDTO.getQualification()).equals(qualification)) {
							            System.out.println("The Qualification already existed");
							            isEqual = true;
							        } else {
							            employeeDTO.setQualification(qualification);
							        }
							    } while (isEqual);
							    int updateEmployeeId = employeeService
                                        .updateEmployeeDetailById(employeeDTO);
				                logger.info("Employee" + updateEmployeeId 
                                        +"Updated");
				                break;

				            case 3:
				                updatePhoneNumber(employeeId, employeeDTO);
				                break;
				                
				            case 4:
				                updateAddress();
				                break;
				            
				            case 5:
				                System.out.println("EXIT");
				                
							default:  
								System.out.println("ENTER NUMERIC OPTION [1- 5]");
					    } 
					} catch (NumberFormatException numberFormatException) {
		                System.out.println("ENTER VALID NUMERIC OPTION [1-5");
		            }
		        } while (choice != 5);
            } else {
                logger.info("Employee Not Found");
            }
        } catch (NumberFormatException numberFormatException) {
            logger.warn("ENTER VALID EMPLOYEEID");
        }     
    }*/

    /**
     *  Display employee 
     */
   /* public void showEmployeeDetail() {
        Map<Integer, EmployeeDTO> employeeDTO = employeeService
                .showEmployeeDetail();
        if(! employeeDTO.isEmpty()) {
            for (Map.Entry<Integer, EmployeeDTO> employeeValue : employeeDTO
                    .entrySet()) 
                System.out.println(employeeValue.getValue()); 
               
	    } else {
            logger.info("EMPLOYEE NOT FOUND");
        }
    }*/

    /**
     *  Delete employee
     */
    /*public void deleteEmployee() {
        System.out.println("DELETE PARTICULAR DETAIL OF EMPLOYEE");
		try {
		    System.out.println("Enter EmployeeID:");
		    int employeeId = Integer.parseInt(scanner.nextLine());
		    int deleteEmployee = employeeService
	        .deleteEmployeeDetailById(employeeId);
                if (deleteEmployee != 0) {
                    logger.info("Employee " + deleteEmployee 
		                    + " record deleted");
                } else {
                    logger.info("\nTHERE IS NO EMPLOYEE FOUND");
                }
		} catch (NumberFormatException numberFormatException) {
		    logger.warn("ENTER VALID EMPLOYEEID");
        }
    }*/

   /*
    *  Update PhoneNumber 
    */
   /* private void updatePhoneNumber(int employeeId, EmployeeDTO employeeDTO) {
    
        String employeePhoneNumberType;	
		PhoneNumber phoneNumber = new PhoneNumber();
       	System.out.println("If you want to add new number press 1 " 
               	+ "or If you want Update Existing PhoneNumber press 2");
		Set<PhoneNumber> phoneNumbers = employeeDTO.getPhoneNumber();
		int choice = Integer.parseInt(scanner.nextLine());
	    switch (choice) {
	    	case 1: 

    	    	phoneNumbers.add(getPhoneNumber(employeeDTO));
    	        employeeDTO.setPhoneNumber(phoneNumbers);
    	        employeeDTO.setEmployeeId(employeeId);
                int updateEmployeeId = employeeService
                		.updateEmployeeDetailById(employeeDTO);
                logger.warn("Employee"+ updateEmployeeId + " Updated");
    	        break;
   
			case 2:
            	System.out.println("Enter Existing Employee phoneNumber:");
		        String employeePhoneNumber = scanner.nextLine();
				if (Validation.isValidPhoneNumber(employeePhoneNumber)) {
                	long mobileNumber = Long.parseLong(employeePhoneNumber);
                    Set<PhoneNumber> mobileNumbers = employeeDTO.getPhoneNumber();
                   	for (PhoneNumber number: mobileNumbers) {
                    	if (mobileNumber == number.getPhoneNumber()) {
                         	phoneNumbers.remove(number);
                            number = getPhoneNumber(employeeDTO);
                            phoneNumbers.add(number);
                            employeeDTO.setPhoneNumber(phoneNumbers);
                            employeeDTO.setEmployeeId(employeeId); 
                            int updateEmployee = employeeService
                                    .updateEmployeeDetailById(employeeDTO);
                            logger.warn("Employee"+ updateEmployee + " Updated");
                            break;
                         } else {
                    	       System.out.println("PhoneNumber already exist");
                         } 
                     }
                } else {
			    	logger.warn("Enter valid PhoneNumber-PhoneNumber "
                    		+"should be 10 digits");
		       	}  
                break;

           default :
               System.out.println("Invalid");     
	   }
   }*/
    
   /**
    *  This method validate Employee salary
    *
    *  @param pay to check valid salary
    */ 
  /* private static int checkSalary(double pay) throws InvalidSalaryException {
        
        if (pay < 25000) {
            throw new InvalidSalaryException("\nENTER VALID SALARY 25000 OR "
                    + " ABOVE 25000 ");    
        } 
        return 0;
   }  */


    /**
     *  This method is used to allot the workplace
     *
     */
     
   /* public SeatAllotment seatAllotment() {
       boolean isValid = false;
       EmployeeDTO employeeDTO = new EmployeeDTO();
       SeatAllotment seat = new SeatAllotment();
       System.out.println("\n***SEAT ALLOTMENT***");
       
       System.out.println("\nDO YOU WANT TO ALLOT SEAT - if YES press-y " 
                + " if NO press-n");
       try {
           String option = scanner.nextLine();
           switch (option.toLowerCase()) {
               
               case "y":
                   System.out.println("\nIst Floor - press 1");
                   System.out.println("2nd IInd Floor - press 2");
                   System.out.println("\nEnter floor Number");
                   int floor = Integer.parseInt(scanner.nextLine());
                   seat.setFloorNumber(floor);
                   if (floor!=2) {
                       seat.setFirstFloorSeatNumber(EmployeeUtility.getFirstFloorId());  
                   } else { 
                       seat.setSecondFloorSeatNumber(EmployeeUtility.getSecondFloorId());
                   }
			       System.out.println("\nSEAT ALLOTED");
                   break;

               case "n":
                   System.out.println("Exited");
                   break;

               default:
                   System.out.println("Press option y for yes or n for No");
            }
          
      } catch (InputMismatchException inputMismatchException) {
          System.out.println("Enter y/Y or N/n");
      }
      return seat;
    }*/

    /**
     * This method is used to get PhoneNumber
     */
    /*public PhoneNumber getPhoneNumber(EmployeeDTO employeeDTO) {
       
        boolean isValid = false;
        String employeePhoneNumber;
        String employeePhoneNumberType;
        String countryCode;
        long mobileNumber;
        PhoneNumber phoneNumber = new PhoneNumber();
        do {
            System.out.println("\nEnter PhoneNumberType: type 'Home' if this is "
                    + "personal number or type 'Office' if this is office number ");
            employeePhoneNumberType = scanner.nextLine();
            if (employeePhoneNumberType.equals("Home") 
                    || employeePhoneNumberType.equals("Office")) {
                phoneNumber.setPhoneNumberType(employeePhoneNumberType);
                isValid = true;
            } else {
                System.out.println( "Enter Home if this is personal Number"
                        + " Or Enter Office if this is Office Number");
            }
        } while(!isValid);
        
        isValid = false;
        Set<PhoneNumber> phoneNumbers = employeeDTO.getPhoneNumber();
        Set<Long> longPhoneNumbers = new HashSet<>();
        for (PhoneNumber number : phoneNumbers) {
            longPhoneNumbers.add(number.getPhoneNumber());
        }
        do {
            System.out.println("\nEnter PhoneNumber:");
            employeePhoneNumber = scanner.nextLine();  
            if (Validation.isValidPhoneNumber(employeePhoneNumber)) {
                mobileNumber = Long.parseLong(employeePhoneNumber);
                if (phoneNumbers != null) {
                    if (longPhoneNumbers.contains(mobileNumber)){
                       System.out.println("Already Exist");
                    } else {
                        phoneNumber.setPhoneNumber(mobileNumber);
                        isValid = true;
                        break;
                    }
                } else {
                    phoneNumber.setPhoneNumber(mobileNumber);
                    isValid = true;
                }
            } else {
                System.out.println( "Enter valid phoneNumber"
                        + "- PhoneNumber should be 10 digits"
                        + "- PhoneNumber should starts between (6-9)");
            }
        } while(!isValid);

        isValid = false;
        do {
            System.out.println("\nEnter CountryCode:(+91)");
            countryCode = scanner.nextLine();
            if (Validation.isValidCountryCode(countryCode)) {  
                phoneNumber.setCountryCode(countryCode);
                isValid = true;
            } else {
                System.out.println("Enter Valid CountryCode - (+91)");
            }
        } while(!isValid);
       
        return phoneNumber;   
     }*/
    
    /**
     * This method is used to get address field
     */
   /* public Address getAddress() {

        boolean isValid = false;
        String doorNo;
        String city;
        String streetName;
        String pincode;

        Address addresses = new Address();
        System.out.println("\n***ADDRESS FIELD***");
        
        do {
        	System.out.println("\nEnter DoorNo:");
            doorNo = scanner.nextLine();
            if (Validation.isValidDoorNumber(doorNo)) {
        		addresses.setDoorNumber(Integer.parseInt(doorNo));
                isValid = true;
			} else {
            	System.out.println("Enter valid DoorNumber");
			}
		} while (!isValid);

        isValid = false;
        do {
        	System.out.println("\nEnter City:");
            city = scanner.nextLine();
			if (Validation.isValidCity(city)) {
        		addresses.setCity(city);
                isValid = true;
			} else {
        		System.out.println("Enter valid CityName");
			}
		} while (!isValid);

        isValid = false;
		do{
        	System.out.println("\nEnter StreetName:");
			streetName = scanner.nextLine();
			if (Validation.isValidStreetName(streetName)) {
        		addresses.setStreetName(streetName);
                isValid = true;
			} else {
				System.out.println("Enter valid StreetName");
			}
		} while (!isValid);

        isValid = false;
		do {
        	System.out.println("\nEnter Pincode");
            pincode = scanner.nextLine();
			if (Validation.isValidPincode(pincode)) {
            	addresses.setPincode(Integer.parseInt(pincode));
                isValid = true;
			} else {
				System.out.println("Enter valid pincode ");
			}
        } while (!isValid);

        System.out.println("ADDRESS INSERTED");
        return addresses;
    }*/

    /**
     *  This method is used to update address
     */
   /* public void updateAddress() {

        boolean isValid = false;

        Address address = new Address();
        try {
            System.out.println("Enter EmployeeID");
            int employeeId = Integer.parseInt(scanner.nextLine());
            EmployeeDTO employeeDTO = employeeService
                    .searchEmployeeDetailById(employeeId);
            if (null != employeeDTO) {
                List<Address> addresses = employeeDTO.getAddress();
                System.out.println("Press 1- to add Address");
                System.out.println("Press 2- to update Address");
                int choice = Integer.parseInt(scanner.nextLine());
                switch (choice) {
                    case 1:

                        System.out.println("Enter New Address:");
                        address = getAddress();
                        addresses.add(address);
                        employeeDTO.setAddress(addresses);
                        int updateEmployeeId = employeeService
                                .updateEmployeeDetailById(employeeDTO);
                        logger.info("Employee" + updateEmployeeId
                                + "Updated");
                        break;

                    case 2:
                        String doorNo;
                        int houseNo = 0;
                        System.out.println("Enter DoorNO:");
                        do {
                            doorNo = scanner.nextLine();
                            if (Validation.isValidDoorNumber(doorNo)) {
                                houseNo = Integer.parseInt(doorNo);
                                address.setDoorNumber(houseNo);
                                isValid = true;
                            } else {
                                System.out.println("Enter valid DoorNumber");
                            }
                        } while (!isValid);

                        for (Address employeeAddress : addresses) {
                            if (houseNo == (employeeAddress.getDoorNumber())) {
                                addresses.remove(employeeAddress);
                                employeeAddress = getAddress();
                                addresses.add(employeeAddress);
                                employeeDTO.setAddress(addresses);
                                int updateEmployeeAddress = employeeService
                                        .updateEmployeeDetailById(employeeDTO);
                                logger.info("Employee" + updateEmployeeAddress
                                        + "Updated");
                                break;
                            }
                        }
                        break;

                    case 3:
                        System.out.println("EXITED");
                        break;

                    default:
                        System.out.println("ENTER VALID NUMERIC NUMBER");
                }
            } else {
                System.out.println("Employee Not Found");
            }
        } catch (NumberFormatException numberFormatException) {
            System.out.println("Enter Valid EmployeeID");
        }
    }*/

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

    	PrintWriter out = response.getWriter();
    	String value = request.getParameter("operation");
        out.println(value);
    	switch (value) {
    	
    	case "Insert": 
    		add(request,response);
    		break;
    	
    	case "Update":
    		update(request,response);	 
    		break;
    	}
    }
    
    public void add(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

    	
    	response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String employeeName = request.getParameter("name");
        String countryCode = request.getParameter("countryCode");
        String phoneNumber = request.getParameter("phoneNumber");
        String designation = request.getParameter("designation");
        String qualification = request.getParameter("qualification");
        String salary = request.getParameter("salary");
        String accountNumber = request.getParameter("accountNumber");
        String ifscCode = request.getParameter("ifscCode");
        String doorNo = request.getParameter("doorNo");
        String phoneNumberType = request.getParameter("phoneNumberType");
        String streetName = request.getParameter("street");
        String floorNumber = request.getParameter("floorNumber");
        String city = request.getParameter("city");
        String pincode = request.getParameter("pincode");
        
        EmployeeDTO employeeDTO = new EmployeeDTO();
        SeatAllotment seat = new SeatAllotment();
        Address address = new Address();
        PhoneNumber mobileNumber = new PhoneNumber();
        
    
        employeeDTO.setEmployeeName(employeeName);
        employeeDTO.setQualification(qualification );
        employeeDTO.setSalary(Integer.parseInt(salary));
        employeeDTO.setDesignation(designation); 
        employeeDTO.setAccountNumber(accountNumber);
        employeeDTO.setIfscCode(ifscCode);
        employeeDTO.setEmailId(EmployeeUtility.employeeEmailId(employeeDTO
                .getEmployeeName(), EmployeeUtility.generateEmployeeId()));
       
        int floor = Integer.parseInt(floorNumber);
        seat.setFloorNumber(floor);
        if (floor!=2) {
            seat.setFirstFloorSeatNumber(EmployeeUtility.getFirstFloorId());  
        } else { 
            seat.setSecondFloorSeatNumber(EmployeeUtility.getSecondFloorId());
        }
        
        address.setDoorNumber(Integer.parseInt(doorNo));
        address.setCity(city);
        address.setStreetName(streetName);
        address.setPincode(Integer.parseInt(pincode));
        
        mobileNumber.setPhoneNumberType(phoneNumberType);
        mobileNumber.setPhoneNumber(Long.parseLong(phoneNumber));
        mobileNumber.setCountryCode(countryCode);
               
       
        
        Set<PhoneNumber> phoneNumbers = new HashSet<PhoneNumber>();
        List<Address> employeeAddress = new ArrayList<Address>();
        
        phoneNumbers.add(mobileNumber);
        employeeAddress.add(address);
        
        employeeDTO.setSeat(seat);
        employeeDTO.setAddress(employeeAddress);
        employeeDTO.setPhoneNumber(phoneNumbers);
        
        int createdId = employeeService.addEmployee(employeeDTO.getEmployeeId(),
                employeeDTO);
        logger.info("\nEMPLOYEE ID " + createdId + " CREATED"); 

    }
 
    public void update(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

    	response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String employeeName = request.getParameter("name");
        String countryCode = request.getParameter("countryCode");
        String phoneNumber = request.getParameter("phoneNumber");
        String designation = request.getParameter("designation");
        String qualification = request.getParameter("qualification");
        String salary = request.getParameter("salary");
        String accountNumber = request.getParameter("accountNumber");
        String ifscCode = request.getParameter("ifscCode");
        String doorNo = request.getParameter("doorNo");
        String phoneNumberType = request.getParameter("phoneNumberType");
        String streetName = request.getParameter("street");
        String floorNumber = request.getParameter("floorNumber");
        String city = request.getParameter("city");
        String pincode = request.getParameter("pincode");

        SeatAllotment seat = new SeatAllotment();
        Address address = new Address();
        PhoneNumber mobileNumber = new PhoneNumber();	
        
        String employeeId = request.getParameter("employeeId");
        int id = Integer.parseInt(employeeId);
        EmployeeDTO employeeDTO = employeeService
                .searchEmployeeDetailById(id);
        if (null != employeeDTO) {
        	 employeeDTO.setEmployeeName(employeeName);
             employeeDTO.setQualification(qualification );
             employeeDTO.setSalary(Integer.parseInt(salary));
             employeeDTO.setDesignation(designation); 
             employeeDTO.setAccountNumber(accountNumber);
             employeeDTO.setIfscCode(ifscCode);
        	

             address.setDoorNumber(Integer.parseInt(doorNo));
             address.setCity(city);
             address.setStreetName(streetName);
             address.setPincode(Integer.parseInt(pincode));

             	
             int floor = Integer.parseInt(floorNumber);
             seat.setFloorNumber(floor);
             if (floor!=2) {
                 seat.setFirstFloorSeatNumber(EmployeeUtility.getFirstFloorId());  
             } else { 
                 seat.setSecondFloorSeatNumber(EmployeeUtility.getSecondFloorId());
             }
			
             mobileNumber.setPhoneNumberType(phoneNumberType);
             mobileNumber.setPhoneNumber(Long.parseLong(phoneNumber));
             mobileNumber.setCountryCode(countryCode);
			
            int updateEmployee = employeeService
                    .updateEmployeeDetailById(employeeDTO);

            out.println(updateEmployee);
	        
        }
    }
    
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
        
        PrintWriter out = response.getWriter();
    	String value = request.getParameter("operation");
        out.println(value);
    	switch (value) {
    	
    	case "Search": 
    		search(request,response);
    		break;
    	
    	case "Display":
    		display(request,response);	 
    		break;
    
    	case "Delete":
    		delete(request,response);	 
    		break;
    	}
    }
    
    public void search(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
    	response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String employeeId = request.getParameter("employeeId");
        int id = Integer.parseInt(employeeId);
        
        EmployeeDTO employeeDTO = employeeService.searchEmployeeDetailById(id);
         if (null != employeeDTO) {
        	 out.println(employeeDTO);
         } else {
        	 out.print("<h4> no data found </h4>");
         }
    	
    }
    
    public void display(HttpServletRequest request, HttpServletResponse response)throws IOException, ServletException {
       
    	PrintWriter out = response.getWriter();
    	Map<Integer, EmployeeDTO> employeeDTO = employeeService
                .showEmployeeDetail();
        if(! employeeDTO.isEmpty()) {
            for (Map.Entry<Integer, EmployeeDTO> employeeValue : employeeDTO
                    .entrySet()) 
                out.println(employeeValue.getValue()); 
               
	    } 
    }
    
    public void delete(HttpServletRequest request, HttpServletResponse response)throws IOException, ServletException {
        
    	String employeeId = request.getParameter("employeeId");
    	int id = Integer.parseInt(employeeId);
	    int deleteEmployee = employeeService.deleteEmployeeDetailById(id);
            if (deleteEmployee != 0) {
                logger.info("Employee " + deleteEmployee 
	                    + " record deleted");
            
            } else {
               logger.info("\nTHERE IS NO EMPLOYEE FOUND");
           
            }
    }
}


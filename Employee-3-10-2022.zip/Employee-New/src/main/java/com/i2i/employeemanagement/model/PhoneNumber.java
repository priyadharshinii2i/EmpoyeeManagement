/**  
 *  Copyright (c) All rights reserved.
 */
package com.i2i.employeemanagement.model;

import java.lang.StringBuilder;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *  This class has Attributes of PhoneNumber
 *
 *  @author Priyadharshini Gunasekaran
 *
 *  version JAVA 8
 */
public class PhoneNumber {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
    private int id;
	
	@Column(name="phone_Number")
	private long phoneNumber;
	
	@Column(name="country_code")
	private String countryCode;
	
	@Column(name="phoneNumber_type")
	private String phoneNumberType;
   
    public void setId(int id) {
        this.id = id;
    }
    
    public int getId() {
        return id;
    }
    
	public void setPhoneNumber(long phoneNumber) {
    	this.phoneNumber = phoneNumber;
    }

	public long getPhoneNumber() {
		return phoneNumber;
    }
    
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
    
    public String getCountryCode() {
        return countryCode;
    }
     
    public void setPhoneNumberType(String phoneNumberType) {
        this.phoneNumberType = phoneNumberType;
    }
    
    public String getPhoneNumberType() {
        return phoneNumberType;
    }

    public String toString() {
       StringBuilder stringBuilder = new StringBuilder();
       return stringBuilder.append("\n CountryCode:").append(getCountryCode())
               .append("\n PhoneNumber Type:").append(getPhoneNumberType())
               .append("\n PhoneNumber:").append(getPhoneNumber()).toString();
    }

}


/**  
 *  
 *  Copyright (c) All rights reserved.
 *  
 */
package com.i2i.employeemanagement.utility;

import java.util.regex.Pattern;
import java.util.Scanner;

/**
 *  This class is used for validation purpose
 * 
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
public class Validation  {

    /**
     *  This method validate the EmailId 
     *
     *  @param emailId is to validate EmailId
     *
     *  @return valid emailId
     *
     */
    public static boolean isValidEmailId(String emailId) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        Pattern pattern = Pattern.compile(emailRegex); 
        return pattern.matcher(emailId).matches();
    }     

    /**
     *  This method validate the phoneNumber
     *
     *  @param phoneNumber is to validate the phoneNumber
     *
     *  @return  Valid phoneNumber
     * 
     */
    public static boolean isValidPhoneNumber(String phoneNumber) {
        String phoneNumberRegex = "^[6-9][0-9]{9}$";
        Pattern pattern = Pattern.compile(phoneNumberRegex); 
        return pattern.matcher(phoneNumber).matches();
    }
    
    /**
     *  This method validate the AccountNumber 
     *
     *  @param AccountNumber is to validate AccountNumber
     *
     *  @return Valid AccountNumber
     * 
     */
    public static boolean isValidAccountNumber(String employeeAccountNumber) {
        String accountNumberRegex = "^[0-9]{14}$";
        Pattern pattern = Pattern.compile(accountNumberRegex); 
        return pattern.matcher(employeeAccountNumber).matches();
    } 
    
    /**
     *  This method validate the qualification
     *
     *  @param Qualificaton is to validate the qualification
     *
     *  @return valid qualification
     *
     */
    public static boolean isValidQualification(String qualification) {
        String qualificationRegex = "^[a-z\\sA-Z.,]+$";
        Pattern pattern = Pattern.compile(qualificationRegex);
        return pattern.matcher(qualification).matches();
    } 
    
    /**
     *  This method validate the ifscCode 
     *
     *  @param ifscCode is to validate the ifscCode
     *
     *  @return valid ifscCode
     *
     */
    public static boolean isValidIfscCode(String ifscCode) {
        String ifscCodeRegex = "^[a-zA-Z0-9]*$";
        Pattern pattern = Pattern.compile(ifscCodeRegex);
        return pattern.matcher(ifscCode).matches();
    }  

    /**
     *  This method validate the employeeDesignation
     *
     *  @param employeeDesignation is to validate the employeeDesignation
     *
     *  @return valid employeeDesignation
     *
     */
    public static boolean isValidDesignation(String employeeDesignation) {
        String designationRegex = "^[a-zA-Z]+$";
        Pattern pattern = Pattern.compile(designationRegex);
        return pattern.matcher(employeeDesignation).matches();
    }

    /**
     *  This method validate the salary
     *
     *  @param salary is to validate the salary
     *
     *  @return valid salary
     *
     */
    public static boolean isValidSalary(String salary) {
        String salaryRegex = "^[0-9.]+$";
        Pattern pattern = Pattern.compile(salaryRegex); 
        return pattern.matcher(salary).matches();
    }

    /**
     *  This method validate the employeeName
     *
     *  @param employeeName is to validate the employeeName
     *
     *  @return valid employeeName
     *
     */
    public static boolean isValidName(String employeeName) {
        String nameRegex = "^[A-Z\\sa-z]+$";
        Pattern pattern = Pattern.compile(nameRegex); 
        return pattern.matcher(employeeName).matches();
    }

    /**
     *  This method validate the doorNumber
     *
     *  @param doorNumber is to validate the doorNumber
     *
     *  @return valid doorNumber
     *
     */
    public static boolean isValidDoorNumber(String doorNumber) {
    	String doorNumberRegex = "^[0-9./]+$";
        Pattern pattern = Pattern.compile(doorNumberRegex); 
        return pattern.matcher(doorNumber).matches();
    }

    /**
     *  This method validate the city
     *
     *  @param city is to validate the city
     *
     *  @return valid city
     *
     */
    public static boolean isValidCity(String city) {
    	String cityRegex = "^[a-zA-Z]+$";
        Pattern pattern = Pattern.compile(cityRegex); 
        return pattern.matcher(city).matches();
    }

    /**
     *  This method validate the streetName
     *
     *  @param streetName is to validate the streetName 
     *
     *  @return valid streetName
     */
    public static boolean isValidStreetName(String streetName) {
    	String streetNameRegex = "^[0-9./A-Z\\sa-z]+$";
        Pattern pattern = Pattern.compile(streetNameRegex); 
        return pattern.matcher(streetName).matches();
    }

    /**
     *  This method validate the pincode
     *
     *  @param pincode is to validate the pincode
     *
     *  @return valid pincode
     */
    public static boolean isValidPincode(String pincode) {
    	String pincodeRegex = "^[0-9]{6}+$";
        Pattern pattern = Pattern.compile(pincodeRegex); 
        return pattern.matcher(pincode).matches();
    }
    
    /**
     *  This method validate the employeePhoneNumberType
     *
     *  @param employeePhoneNumberType is to validate the employeePhoneNumberType
     *
     *  @return valid employeePhoneNumberType
     */
    public static boolean isValidPhoneNumberType(String employeePhoneNumberType) {
    	String employeePhoneNumberTypeRegex = "^[a-zA-Z]+$";
        Pattern pattern = Pattern.compile(employeePhoneNumberTypeRegex); 
        return pattern.matcher(employeePhoneNumberType).matches();
    }
    
     /**
     *  This method validate the countryCode
     *
     *  @param countryCode is to validate the countryCode
     *
     *  @return valid countryCode
     */
    public static boolean isValidCountryCode(String countryCode) {
        String countryCodeRegex = "^[+0-9]+$";
        Pattern pattern = Pattern.compile(countryCodeRegex); 
        return pattern.matcher(countryCode).matches();
    }
}

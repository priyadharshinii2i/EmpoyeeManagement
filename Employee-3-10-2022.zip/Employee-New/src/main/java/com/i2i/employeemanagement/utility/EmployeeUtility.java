/** 
 *  
 *  Copyright (c) All rights reserved.
 *  
 */
package com.i2i.employeemanagement.utility; 
 
/**
 *  This helper class helps to mask the confidential fields. 
 *
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */  
public class EmployeeUtility {

    public static int id = 1001;
    public static int firstFloor = 1;
    public static int secondFloor = 1;
    /**
     *  This method is used to mask the employee phone Number
     *
     *  @param phoneNumber is to mask the phoneNumber. 
     *
     *  @return phoneNumber by masking.
     */
    public static String maskPhoneNumber(long phoneNumber) {
        String mask = "";
        String employeephoneNumber = Long.toString(phoneNumber);
        int size = employeephoneNumber.substring(6).length();

        for (int i=0 ; i < size ; i++) {
            mask += "x";
        }
        return mask = "+91"+ employeephoneNumber.substring(0, 6) + mask;    
    }
    
    /**
     *  This method is used to mask the employee AccountNumber
     *
     *  @param AccountNumber is to mask the AccountNumber. 
     *
     *  @return AccountNumber by masking.
     */
    public static String maskAccountNumber(String accountNumber) {
        String mask = "";
        int size = accountNumber.substring(0, 4).length();

        for (int i=0 ; i < size ; i++) {
            mask += "x";
        }
        mask = mask + accountNumber.substring(4, 9) + mask; 
        return mask;    
    }

    /**
     *  This method is used to generate employeeID
     *
     *  @return auto-generatedEmployeeId 
     */
    public static int generateEmployeeId() {
        return id++;
    }
    
    /**
     *  This method is used to Auto-generate emailID
     *
     *  @param name is to generate emailID
     *
     *  @return auto-generated Email-Id
     */
    public static String employeeEmailId(String employeeName, int id) {
        String employeeId = Integer.toString(id);
        return employeeName.replaceAll("\\s", ".").concat(employeeId.concat("@ideas2it.com"));
    }  
    
    /**
     *  This method is used to generate workplace id
     *
     *  return auto-generated workplace
     */
    public static String getFirstFloorId() {
        return "I2I 1F WS00" + firstFloor++;
    }
    
    /**
     *  This method is used to generate workplace id
     *
     *  return auto-generated workplace
     */
    public static String getSecondFloorId() {
        return "I2I 1F WS00" + secondFloor++;
    }

}

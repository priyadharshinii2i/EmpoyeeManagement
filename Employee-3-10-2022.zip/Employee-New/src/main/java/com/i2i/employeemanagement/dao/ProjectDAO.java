/*  
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
package com.i2i.employeemanagement.dao;


import java.util.HashMap;
import java.util.Map;
import java.sql.SQLException;

import com.i2i.employeemanagement.dto.ProjectDTO;
import com.i2i.employeemanagement.model.Project;

/**
 *  This class used to create, search, update, display and delete
 *  Project object.
 *
 */
public interface ProjectDAO {

    /** 
     *  Used to add project  
     *
     *  @param project to be added 
     *
     *  @param employeeId to be added
     *
     *  @return created employeeId
     */ 
    public int insertProject(int id, Project project);

    /**
     *  Used to search Project
     * 
     *  @param employeeId used to find project
     *  
     *  @return project 
     *  
     */
    public Project selectProjectDetailById(int id);

    /** 
     *  Used to update project 
     *
     *  @param emlopyeeId is to find project
     *
     *  @return updated employeeId 
     */
    public int modifyProjectDetailById(int id, Project project);

    /** 
     *  Used to display project 
     *
     *  @return projects
     */
    public Map<Integer, Project> displayProjectDetail();

    /** 
     *  Remove project
     *
     *  @param employeeId is to find project
     *
     *  @return deleted employeeId        
     */
    public int removeProjectDetailById(int id);
    
    /**
     * assignEmpoyeeToProject
     *
     * @param employeeId to find employee
     *
     * @param projectId to find projectId
     */
    public void assignEmployeeToProject(int employeeId, int projectId); 
}

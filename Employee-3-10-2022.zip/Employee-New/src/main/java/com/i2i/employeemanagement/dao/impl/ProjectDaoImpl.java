/*  
 *  @author Priyadharshini Gunasekaran
 *
 *  version java 8
 */
package com.i2i.employeemanagement.dao.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.List;

//import java.sql.Connection;
//mport java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
import org.hibernate.Transaction;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.hibernate.HibernateException;

import com.i2i.employeemanagement.dao.ProjectDAO;
import com.i2i.employeemanagement.dto.ProjectDTO;
import com.i2i.employeemanagement.model.Project;
import com.i2i.employeemanagement.model.Employee;
import com.i2i.employeemanagement.singleton.Singleton;

/**
 *  This class used to create, search, update, display and delete
 *  Project.
 *
 */
public class ProjectDaoImpl implements ProjectDAO{
   
   /*private static Map<Integer, Project> projects = new HashMap<Integer, 
                                                               Project>();*/
    
    Singleton singleton = Singleton.getInstance();
    SessionFactory sessionFactory = singleton.getSessionFactory();
    Session session = null;
    Transaction transaction = null;  
    /** 
     *  Used to insert project 
     *
     *  @param project to be added
     *  
     *  @param id to be added
     *
     *  @return created id
     */
    public int insertProject(int id, Project project) {
        
        session = sessionFactory.openSession();
        try {
            transaction = session.beginTransaction();
            session.save(project);
            transaction.commit();
        } catch (HibernateException hibernateException) {
            hibernateException.printStackTrace();
        }
        finally {
            session.close();
        }
   
         return project.getId();
    }

    /**
     *  Used to select project
     * 
     *  @param id is to find project
     *  
     *  @return project
     *  
     */
     
    public Project selectProjectDetailById(int id) {
    
        session = sessionFactory.openSession();
        Project project = new Project();
        try {
            transaction = session.beginTransaction();
            project = session.get(Project.class, id); 
        } catch (HibernateException hibernateException){
            hibernateException.printStackTrace();
        }
        finally {
            session.close();
        }
        return project;       
           
    }

    /** 
     *  Used to update project
     *
     *  @param id is to find project
     *
     *  @return updated id 
     */
    public int modifyProjectDetailById(int id, Project project) {
    
        session = sessionFactory.openSession();
        try {
            transaction = session.beginTransaction();
            session.update(project);
            transaction.commit();
        } catch (HibernateException hibernateException) {
            hibernateException.printStackTrace();
        }
        finally {
            session.close();
        }
        return project.getId();
    }
    
    /** 
     *  Used to display project 
     *
     *  @return projects
     */
    public Map<Integer,Project> displayProjectDetail() {
    
        Map<Integer,Project> projectMap = new HashMap();
        Project project = new Project();
        
        session = sessionFactory.openSession();
        try {
            transaction = session.beginTransaction();
            String projectHql = "FROM Project";
            Query projectQuery = session.createQuery(projectHql);
            List<Project> projects =  projectQuery.list();
            for (Project projectDetail : projects) {
                projectMap.put(project.getId(), projectDetail);
            }
        } catch (HibernateException hibernateException) {
            hibernateException.printStackTrace();
        } 
        return projectMap;
    }

    /** 
     *  Remove project 
     *
     *  @param id is to find project
     *
     *  @return deleted id 
     */
    public int removeProjectDetailById(int id) {
        
        session = sessionFactory.openSession();
        Project project = new Project();
        try {
            transaction = session.beginTransaction();
            project = session.get(Project.class, id);
            session.delete(project);
            transaction.commit();
        } catch (HibernateException hibernateException) {
            hibernateException.printStackTrace();
        }
        finally {
            session.close();
        }
        return project.getId();
   }
    
   public void assignEmployeeToProject(int employeeId, int id) {
   
   }
}
